import { User, MonitoringEntry, AttendanceEntry, JournalEntry, ObservationEntry, ActivityEntry } from './types';

const KEYS = {
  users: 'pkl_users',
  monitoring: 'pkl_monitoring',
  attendance: 'pkl_attendance',
  journal: 'pkl_journal',
  observation: 'pkl_observation',
  activity: 'pkl_activity',
  session: 'pkl_session',
  settings: 'pkl_settings',
};

export interface AttendanceSettings {
  startHour: string;
  endHour: string;
  toleranceMinutes: number;
  jurusanAktif: string;
}

const defaultSettings: AttendanceSettings = { startHour: '07:00', endHour: '17:00', toleranceMinutes: 30, jurusanAktif: 'Teknik Komputer dan Jaringan' };

// Teks kustom yang bisa diedit admin (untuk kop surat, judul, label, dll)
export interface TextCustom {
  sekolahNama: string;
  sekolahAlamat: string;
  sekolahKontak: string;
  kopSubtitle: string;
  labelDaftarHadir: string;
  labelJurnal: string;
  labelObservasi: string;
  labelCatatan: string;
  labelMonitoring: string;
  labelLengkap: string;
  footerText: string;
  catatanTambahan: string;
}

const defaultTextCustom: TextCustom = {
  sekolahNama: 'SMK MUHAMMADIYAH 2 PLAYEN',
  sekolahAlamat: 'JL. Manthous Km. 1 Jatisari, Playen, Playen, Gunungkidul, DI Yogyakarta Kode Pos 55861',
  sekolahKontak: 'Telp. 0274392504 | Email: info@smkmuha2playen.sch.id',
  kopSubtitle: 'Sistem Jurnal Laporan Praktek Kerja Lapangan',
  labelDaftarHadir: 'DAFTAR HADIR PESERTA PKL',
  labelJurnal: 'JURNAL KEGIATAN PKL',
  labelObservasi: 'LAPORAN HASIL OBSERVASI PKL',
  labelCatatan: 'CATATAN KEGIATAN PKL',
  labelMonitoring: 'CATATAN MONITORING GURU PEMBIMBING',
  labelLengkap: 'LAPORAN LENGKAP PRAKTEK KERJA LAPANGAN',
  footerText: '© SMK Muhammadiyah 2 Playen',
  catatanTambahan: 'Dokumen ini dibuat secara digital melalui Sistem Jurnal PKL SMK Muhammadiyah 2 Playen.',
};

export const textCustomStore = {
  get: () => load<TextCustom>(KEYS.settings + '_textcustom', defaultTextCustom),
  save: (v: TextCustom) => save(KEYS.settings + '_textcustom', v),
  defaults: defaultTextCustom,
};

// Tema warna
export interface ThemeDef {
  id: string;
  name: string;
  primary: string; // tailwind gradient from-
  primary2: string; // gradient to-
  primaryHover: string;
  primaryText: string; // text color
  ring: string; // focus ring
  accentBg: string; // light bg accent
  accentText: string;
  badgeBg: string;
  badgeText: string;
  swatch: string; // preview color
}

export const themes: ThemeDef[] = [
  { id: 'emerald', name: 'Hijau Muhammadiyah', primary: 'from-emerald-600', primary2: 'to-emerald-800', primaryHover: 'hover:bg-emerald-800', primaryText: 'text-emerald-700', ring: 'focus:ring-emerald-500', accentBg: 'bg-emerald-50', accentText: 'text-emerald-800', badgeBg: 'bg-emerald-100', badgeText: 'text-emerald-700', swatch: '#059669' },
  { id: 'blue', name: 'Biru Modern', primary: 'from-blue-600', primary2: 'to-blue-800', primaryHover: 'hover:bg-blue-800', primaryText: 'text-blue-700', ring: 'focus:ring-blue-500', accentBg: 'bg-blue-50', accentText: 'text-blue-800', badgeBg: 'bg-blue-100', badgeText: 'text-blue-700', swatch: '#2563eb' },
  { id: 'indigo', name: 'Ungu Elegan', primary: 'from-indigo-600', primary2: 'to-indigo-800', primaryHover: 'hover:bg-indigo-800', primaryText: 'text-indigo-700', ring: 'focus:ring-indigo-500', accentBg: 'bg-indigo-50', accentText: 'text-indigo-800', badgeBg: 'bg-indigo-100', badgeText: 'text-indigo-700', swatch: '#4f46e5' },
  { id: 'rose', name: 'Merah Muda', primary: 'from-rose-600', primary2: 'to-rose-800', primaryHover: 'hover:bg-rose-800', primaryText: 'text-rose-700', ring: 'focus:ring-rose-500', accentBg: 'bg-rose-50', accentText: 'text-rose-800', badgeBg: 'bg-rose-100', badgeText: 'text-rose-700', swatch: '#e11d48' },
  { id: 'amber', name: 'Jingga Hangat', primary: 'from-amber-600', primary2: 'to-amber-800', primaryHover: 'hover:bg-amber-800', primaryText: 'text-amber-700', ring: 'focus:ring-amber-500', accentBg: 'bg-amber-50', accentText: 'text-amber-800', badgeBg: 'bg-amber-100', badgeText: 'text-amber-700', swatch: '#d97706' },
  { id: 'teal', name: 'Teal Segar', primary: 'from-teal-600', primary2: 'to-teal-800', primaryHover: 'hover:bg-teal-800', primaryText: 'text-teal-700', ring: 'focus:ring-teal-500', accentBg: 'bg-teal-50', accentText: 'text-teal-800', badgeBg: 'bg-teal-100', badgeText: 'text-teal-700', swatch: '#0d9488' },
  { id: 'violet', name: 'Violet Kreatif', primary: 'from-violet-600', primary2: 'to-violet-800', primaryHover: 'hover:bg-violet-800', primaryText: 'text-violet-700', ring: 'focus:ring-violet-500', accentBg: 'bg-violet-50', accentText: 'text-violet-800', badgeBg: 'bg-violet-100', badgeText: 'text-violet-700', swatch: '#7c3aed' },
  { id: 'slate', name: 'Abu Profesional', primary: 'from-slate-700', primary2: 'to-slate-900', primaryHover: 'hover:bg-slate-900', primaryText: 'text-slate-700', ring: 'focus:ring-slate-500', accentBg: 'bg-slate-50', accentText: 'text-slate-800', badgeBg: 'bg-slate-100', badgeText: 'text-slate-700', swatch: '#475569' },
  { id: 'cyan', name: 'Cyan Cerah', primary: 'from-cyan-600', primary2: 'to-cyan-800', primaryHover: 'hover:bg-cyan-800', primaryText: 'text-cyan-700', ring: 'focus:ring-cyan-500', accentBg: 'bg-cyan-50', accentText: 'text-cyan-800', badgeBg: 'bg-cyan-100', badgeText: 'text-cyan-700', swatch: '#0891b2' },
  { id: 'fuchsia', name: 'Fuchsia Ceria', primary: 'from-fuchsia-600', primary2: 'to-fuchsia-800', primaryHover: 'hover:bg-fuchsia-800', primaryText: 'text-fuchsia-700', ring: 'focus:ring-fuchsia-500', accentBg: 'bg-fuchsia-50', accentText: 'text-fuchsia-800', badgeBg: 'bg-fuchsia-100', badgeText: 'text-fuchsia-700', swatch: '#c026d3' },
];

export const themeStore = {
  get: () => load<string>(KEYS.settings + '_theme', 'emerald'),
  save: (v: string) => save(KEYS.settings + '_theme', v),
  current: () => themes.find(t => t.id === themeStore.get()) || themes[0],
};

export const settingsStore = {
  get: () => load<AttendanceSettings>(KEYS.settings, defaultSettings),
  save: (v: AttendanceSettings) => save(KEYS.settings, v),
};

// Tanda tangan global (bisa diakses oleh guru & admin)
// Dipisahkan per-guru: setiap guru punya tanda tangan sendiri
// + tanda tangan DUDI yang dikelola guru/admin (bisa banyak)
export interface SignatureItem {
  id: string;
  type: 'guru' | 'dudi';
  ownerUserId?: string; // untuk type=guru -> id user guru
  namaLengkap: string;
  nbm: string;
  showNbm?: boolean; // tampilkan/sembunyikan NBM pada hasil cetak/PDF
  jabatan?: string;
  tempatPkl?: string; // untuk type=dudi
  signature: string; // base64
  createdAt: string;
}

const defaultSignatures: SignatureItem[] = [];

export const signaturesStore = {
  all: () => load<SignatureItem[]>(KEYS.settings + '_signatures', defaultSignatures),
  save: (v: SignatureItem[]) => save(KEYS.settings + '_signatures', v),
  add: (item: SignatureItem) => {
    const list = signaturesStore.all(); list.push(item); signaturesStore.save(list);
  },
  update: (item: SignatureItem) => {
    const list = signaturesStore.all().map(x => x.id === item.id ? item : x);
    signaturesStore.save(list);
  },
  remove: (id: string) => {
    signaturesStore.save(signaturesStore.all().filter(x => x.id !== id));
  },
  byType: (type: 'guru' | 'dudi') => signaturesStore.all().filter(x => x.type === type),
  guruByUser: (userId: string) => signaturesStore.all().find(x => x.type === 'guru' && x.ownerUserId === userId),
};

function load<T>(key: string, fallback: T): T {
  try {
    const raw = localStorage.getItem(key);
    if (!raw) return fallback;
    return JSON.parse(raw) as T;
  } catch {
    return fallback;
  }
}

function save<T>(key: string, value: T) {
  localStorage.setItem(key, JSON.stringify(value));
}

const defaultUsers: User[] = [
  { id: 'u1', username: 'admin', password: 'admin123', role: 'admin', name: 'Administrator' },
  { id: 'u2', username: 'guru', password: 'guru123', role: 'guru', name: 'Bapak Pembimbing', nip: '198501012010011001' },
  { id: 'u3', username: 'siswa', password: 'siswa123', role: 'siswa', name: 'Ahmad Fauzi', nis: '12345', kelas: 'XII TKJ 1', jurusan: 'Teknik Komputer dan Jaringan', tempatPkl: 'PT. Tech Nusantara', pembimbingId: 'u2' },
  { id: 'u4', username: 'siswa2', password: 'siswa123', role: 'siswa', name: 'Siti Rahayu', nis: '12346', kelas: 'XII TKJ 1', jurusan: 'Teknik Komputer dan Jaringan', tempatPkl: 'CV. Digital Kreatif', pembimbingId: 'u2' },
];

export function initStore() {
  if (!localStorage.getItem(KEYS.users)) save(KEYS.users, defaultUsers);
  if (!localStorage.getItem(KEYS.monitoring)) save(KEYS.monitoring, []);
  if (!localStorage.getItem(KEYS.attendance)) save(KEYS.attendance, []);
  if (!localStorage.getItem(KEYS.journal)) save(KEYS.journal, []);
  if (!localStorage.getItem(KEYS.observation)) save(KEYS.observation, []);
  if (!localStorage.getItem(KEYS.activity)) save(KEYS.activity, []);
}

export const usersStore = {
  all: () => load<User[]>(KEYS.users, []),
  save: (v: User[]) => save(KEYS.users, v),
  login: (username: string, password: string) => {
    const u = load<User[]>(KEYS.users, []).find(x => x.username === username && x.password === password);
    if (u) { save(KEYS.session, u); return u; }
    return null;
  },
  session: () => load<User | null>(KEYS.session, null),
  logout: () => localStorage.removeItem(KEYS.session),
  update: (u: User) => {
    const list = load<User[]>(KEYS.users, []).map(x => x.id === u.id ? u : x);
    save(KEYS.users, list);
    const s = load<User | null>(KEYS.session, null);
    if (s && s.id === u.id) save(KEYS.session, u);
  },
  add: (u: User) => {
    const list = load<User[]>(KEYS.users, []);
    list.push(u);
    save(KEYS.users, list);
  },
  remove: (id: string) => {
    const list = load<User[]>(KEYS.users, []).filter(x => x.id !== id);
    save(KEYS.users, list);
  },
  byRole: (role: string) => load<User[]>(KEYS.users, []).filter(x => x.role === role),
};

function crud<T extends { id: string }>(key: string) {
  return {
    all: () => load<T[]>(key, []),
    save: (v: T[]) => save(key, v),
    add: (item: T) => {
      const list = load<T[]>(key, []);
      list.push(item);
      save(key, list);
    },
    update: (item: T) => {
      const list = load<T[]>(key, []).map(x => x.id === item.id ? item : x);
      save(key, list);
    },
    remove: (id: string) => {
      const list = load<T[]>(key, []).filter(x => x.id !== id);
      save(key, list);
    },
  };
}

export const monitoringStore = crud<MonitoringEntry>(KEYS.monitoring);
export const attendanceStore = crud<AttendanceEntry>(KEYS.attendance);
export const journalStore = crud<JournalEntry>(KEYS.journal);
export const observationStore = crud<ObservationEntry>(KEYS.observation);
export const activityStore = crud<ActivityEntry>(KEYS.activity);

export function uid() { return 'id_' + Math.random().toString(36).slice(2, 10); }

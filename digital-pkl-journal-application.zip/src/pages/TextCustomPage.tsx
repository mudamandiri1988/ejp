import { useState } from 'react';
import { textCustomStore, TextCustom } from '../store';

export default function TextCustomPage() {
  const [text, setText] = useState<TextCustom>(textCustomStore.get());
  const [saved, setSaved] = useState(false);

  function save() {
    textCustomStore.save(text);
    setSaved(true);
    setTimeout(() => setSaved(false), 2500);
  }

  function reset() {
    if (confirm('Kembalikan semua teks ke default?')) {
      setText(textCustomStore.defaults);
      textCustomStore.save(textCustomStore.defaults);
      setSaved(true);
      setTimeout(() => setSaved(false), 2500);
    }
  }

  const fields: { key: keyof TextCustom; label: string; textarea?: boolean; group: string }[] = [
    { key: 'sekolahNama', label: '🏫 Nama Sekolah (Header)', group: 'Kop Surat' },
    { key: 'sekolahAlamat', label: 'Alamat Sekolah', group: 'Kop Surat' },
    { key: 'sekolahKontak', label: 'Kontak (Telp/Email)', group: 'Kop Surat' },
    { key: 'kopSubtitle', label: 'Subtitle Header', group: 'Kop Surat' },
    { key: 'labelDaftarHadir', label: '📝 Judul Daftar Hadir', group: 'Label Formulir' },
    { key: 'labelJurnal', label: '📓 Judul Jurnal Kegiatan', group: 'Label Formulir' },
    { key: 'labelObservasi', label: '🔍 Judul Laporan Observasi', group: 'Label Formulir' },
    { key: 'labelCatatan', label: '📑 Judul Catatan Kegiatan', group: 'Label Formulir' },
    { key: 'labelMonitoring', label: '📋 Judul Monitoring Guru', group: 'Label Formulir' },
    { key: 'labelLengkap', label: '📄 Judul Laporan Lengkap', group: 'Label Formulir' },
    { key: 'footerText', label: '📎 Teks Footer', group: 'Lainnya', textarea: true },
    { key: 'catatanTambahan', label: '💬 Catatan Tambahan', group: 'Lainnya', textarea: true },
  ];

  const groups = Array.from(new Set(fields.map(f => f.group)));

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between flex-wrap gap-3">
        <div>
          <h2 className="text-2xl font-bold text-slate-800">✏️ Kustomisasi Teks</h2>
          <p className="text-sm text-slate-500">Ubah nama sekolah, alamat, judul formulir, dan teks lainnya. Semua perubahan akan tersimpan dan diterapkan otomatis di seluruh sistem.</p>
        </div>
        <div className="flex gap-2">
          <button onClick={reset} className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg text-sm">Reset Default</button>
          <button onClick={save} className="px-5 py-2 bg-emerald-700 hover:bg-emerald-800 text-white rounded-lg font-medium">💾 Simpan Pengaturan</button>
          {saved && <span className="text-sm text-emerald-600 self-center">✓ Tersimpan</span>}
        </div>
      </div>

      {groups.map(group => (
        <div key={group} className="bg-white rounded-xl shadow p-5 border border-slate-200">
          <h3 className="font-bold text-slate-800 mb-4 pb-2 border-b border-slate-200">{group}</h3>
          <div className="grid md:grid-cols-2 gap-4">
            {fields.filter(f => f.group === group).map(f => (
              <div key={f.key} className={f.textarea ? 'md:col-span-2' : ''}>
                <label className="block text-sm font-medium text-slate-700 mb-1">{f.label}</label>
                {f.textarea ? (
                  <textarea rows={3} value={(text as any)[f.key]} onChange={e => setText({ ...text, [f.key]: e.target.value })} className="w-full px-3 py-2 border border-slate-300 rounded-lg" />
                ) : (
                  <input value={(text as any)[f.key]} onChange={e => setText({ ...text, [f.key]: e.target.value })} className="w-full px-3 py-2 border border-slate-300 rounded-lg" />
                )}
              </div>
            ))}
          </div>
        </div>
      ))}

      <div className="bg-amber-50 border border-amber-200 rounded-xl p-4 text-sm text-amber-800">
        💡 <b>Catatan:</b> Setelah menyimpan perubahan, teks baru akan muncul otomatis di header, judul formulir, dan lembar cetak/export PDF. Silakan buka halaman lain untuk melihat hasilnya.
      </div>
    </div>
  );
}

import { useState } from 'react';
import { settingsStore, usersStore } from '../store';
import { useTheme } from '../components/ThemeProvider';

interface Props { onLogin: (user: any) => void; }

export default function LoginPage({ onLogin }: Props) {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const theme = useTheme().theme;
  const settings = settingsStore.get();

  function submit(e: React.FormEvent) {
    e.preventDefault();
    const u = usersStore.login(username, password);
    if (u) onLogin(u);
    else setError('Username atau password salah');
  }

  return (
    <div className={`min-h-screen flex items-center justify-center bg-gradient-to-br ${theme.primary} ${theme.primary2} p-4 sm:p-6`}>
      <div className="w-full max-w-5xl bg-white rounded-2xl shadow-2xl overflow-hidden grid md:grid-cols-2">
        <div className={`p-8 md:p-12 bg-gradient-to-br ${theme.primary} ${theme.primary2} text-white flex flex-col justify-center`}>
          <h1 className="text-2xl sm:text-3xl font-bold leading-tight">SMK MUHAMMADIYAH<br/>2 PLAYEN</h1>
          <div className="mt-4 h-1 w-20 bg-white/40 rounded-full"></div>
          <p className="mt-6 text-white/90 leading-relaxed text-sm sm:text-base">Sistem Jurnal Laporan Praktek Kerja Lapangan (PKL) digital.<br/><span className="text-xs text-white/70 mt-1 block">JL. Manthous Km. 1 Jatisari, Playen, Gunungkidul, DIY 55861<br/>Telp. 0274392504 | info@smkmuha2playen.sch.id</span></p>
          <div className="mt-5 rounded-xl bg-white/15 px-4 py-3 text-white backdrop-blur-sm">
            <div className="text-xs font-semibold uppercase tracking-wider text-white/70">Jurusan Aktif PKL</div>
            <div className="mt-1 text-base font-bold leading-snug">{settings.jurusanAktif || '-'}</div>
          </div>
          <div className="mt-6 space-y-2 text-sm text-white/90 hidden sm:block">
            <div>✅ Catatan Monitoring Guru Pembimbing</div>
            <div>✅ Daftar Hadir PKL Siswa + Status Hadir/Sakit/Ijin</div>
            <div>✅ Jurnal & Catatan Kegiatan PKL</div>
            <div>✅ Laporan Hasil Observasi PKL</div>
            <div>✅ Export PDF & Cetak Otomatis</div>
            <div>✅ 10 Pilihan Tema Warna</div>
          </div>
        </div>
        <div className="p-8 md:p-12 flex flex-col justify-center">
          <h2 className="text-2xl font-bold text-slate-800">Login Sistem</h2>
          <p className="text-sm text-slate-500 mt-1">Masukkan username dan password Anda</p>
          <form onSubmit={submit} className="mt-6 space-y-4">
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-1">Username</label>
              <input value={username} onChange={e => setUsername(e.target.value)} className="w-full px-4 py-2.5 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-slate-500" placeholder="Username" autoComplete="username" />
            </div>
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-1">Password</label>
              <input type="password" value={password} onChange={e => setPassword(e.target.value)} className="w-full px-4 py-2.5 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-slate-500" placeholder="Password" autoComplete="current-password" />
            </div>
            {error && <div className="text-sm text-rose-600 bg-rose-50 border border-rose-200 rounded-lg px-3 py-2">{error}</div>}
            <button type="submit" className={`w-full py-2.5 bg-gradient-to-r ${theme.primary} ${theme.primary2} hover:opacity-90 text-white font-semibold rounded-lg shadow-sm`}>Masuk</button>
          </form>
          <div className="mt-6 text-xs text-slate-500 bg-slate-50 rounded-lg p-4 border border-slate-200">
            Hubungi admin sekolah jika belum memiliki akun login.
          </div>
        </div>
      </div>
    </div>
  );
}

import { useState, useRef } from 'react';
import { User, Role } from '../types';
import { usersStore, uid } from '../store';
import * as XLSX from 'xlsx';

interface BulkUser {
  username: string;
  password: string;
  name: string;
  role: Role;
  nip?: string;
  nis?: string;
  kelas?: string;
  jurusan?: string;
  tempatPkl?: string;
  pembimbingUsername?: string;
}

export default function UsersPage() {
  const [tick, setTick] = useState(0);
  const [editing, setEditing] = useState<User | null>(null);
  const [filter, setFilter] = useState<Role | 'all'>('all');
  const [bulkOpen, setBulkOpen] = useState(false);
  const [bulkPreview, setBulkPreview] = useState<BulkUser[]>([]);
  const [bulkError, setBulkError] = useState('');
  const [bulkSuccess, setBulkSuccess] = useState('');
  const fileRef = useRef<HTMLInputElement>(null);

  const users = usersStore.all();
  const list = filter === 'all' ? users : users.filter(u => u.role === filter);
  void tick;

  const empty: User = { id: '', username: '', password: '', role: 'siswa', name: '', nip: '', nis: '', kelas: '', jurusan: '', tempatPkl: '', pembimbingId: '' };

  function save(u: User) {
    if (u.id) usersStore.update(u);
    else usersStore.add({ ...u, id: uid() });
    setEditing(null);
    setTick(t => t + 1);
  }

  function remove(id: string) {
    if (confirm('Hapus pengguna ini?')) { usersStore.remove(id); setTick(t => t + 1); }
  }

  const sampleData: BulkUser[] = [
    { username: 'guru_budi', password: 'guru123', name: 'Budi Santoso, S.Pd.', role: 'guru', nip: '198501012010012001' },
    { username: 'guru_siti', password: 'guru123', name: 'Siti Rahmawati, S.T.', role: 'guru', nip: '198802022015002001' },
    { username: 'siswa_001', password: 'siswa123', name: 'Ahmad Fauzi', role: 'siswa', nis: '20240001', kelas: 'XII TKJ 1', jurusan: 'Teknik Komputer dan Jaringan', tempatPkl: 'PT. Tech Nusantara', pembimbingUsername: 'guru_budi' },
    { username: 'siswa_002', password: 'siswa123', name: 'Siti Nurhaliza', role: 'siswa', nis: '20240002', kelas: 'XII TKJ 1', jurusan: 'Teknik Komputer dan Jaringan', tempatPkl: 'CV. Digital Kreatif', pembimbingUsername: 'guru_budi' },
    { username: 'siswa_003', password: 'siswa123', name: 'Bima Sakti', role: 'siswa', nis: '20240003', kelas: 'XII MM 1', jurusan: 'Multimedia', tempatPkl: 'Studio Grafis Indonesia', pembimbingUsername: 'guru_siti' },
  ];

  const colHeaders = ['username', 'password', 'name', 'role', 'nip', 'nis', 'kelas', 'jurusan', 'tempatPkl', 'pembimbingUsername'];

  function downloadTemplate(format: 'csv' | 'json' | 'xlsx') {
    if (format === 'xlsx') {
      // Generate Excel file
      const wsData = [colHeaders, ...sampleData.map(u => colHeaders.map(h => (u as any)[h] || ''))];
      const ws = XLSX.utils.aoa_to_sheet(wsData);
      // Set column widths
      ws['!cols'] = colHeaders.map(h => ({ wch: h === 'tempatPkl' || h === 'jurusan' ? 32 : h === 'name' || h === 'pembimbingUsername' ? 25 : 18 }));
      const wb = XLSX.utils.book_new();
      XLSX.utils.book_append_sheet(wb, ws, 'Data Pengguna');
      XLSX.writeFile(wb, 'template-pengguna.xlsx');
      return;
    }

    let content = '';
    let filename = '';
    let mime = '';

    if (format === 'csv') {
      content = colHeaders.join(',') + '\n' + sampleData.map(u => colHeaders.map(h => `"${(u as any)[h] || ''}"`).join(',')).join('\n');
      filename = 'template-pengguna.csv';
      mime = 'text/csv;charset=utf-8';
    } else {
      content = JSON.stringify(sampleData, null, 2);
      filename = 'template-pengguna.json';
      mime = 'application/json';
    }

    const blob = new Blob([content], { type: mime });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url; a.download = filename;
    document.body.appendChild(a); a.click(); document.body.removeChild(a);
    URL.revokeObjectURL(url);
  }

  function parseExcel(data: ArrayBuffer): BulkUser[] {
    const wb = XLSX.read(data, { type: 'array' });
    const ws = wb.Sheets[wb.SheetNames[0]];
    const json: any[][] = XLSX.utils.sheet_to_json(ws, { header: 1, defval: '' });
    if (json.length < 2) throw new Error('File Excel kosong atau hanya berisi header');

    const headers = json[0].map((h: any) => String(h).trim());
    const rows: BulkUser[] = [];
    for (let i = 1; i < json.length; i++) {
      const cells = json[i];
      // Skip empty rows
      if (!cells || cells.every((c: any) => !c && c !== 0)) continue;
      const obj: any = {};
      headers.forEach((h: string, idx: number) => obj[h] = String(cells[idx] ?? '').trim());
      if (obj.role && !['admin', 'guru', 'siswa'].includes(obj.role)) throw new Error(`Baris ${i + 1}: role "${obj.role}" tidak valid (harus: admin/guru/siswa)`);
      if (obj.username || obj.name) rows.push(obj as BulkUser);
    }
    return rows;
  }

  function parseCSV(text: string): BulkUser[] {
    const lines = text.trim().split(/\r?\n/).filter(l => l.trim());
    if (lines.length < 2) throw new Error('File CSV kosong atau hanya berisi header');
    const headers = lines[0].split(',').map(h => h.trim().replace(/^"|"$/g, ''));
    const rows: BulkUser[] = [];
    for (let i = 1; i < lines.length; i++) {
      const cells: string[] = [];
      let cur = ''; let inQuote = false;
      for (const ch of lines[i]) {
        if (ch === '"') inQuote = !inQuote;
        else if (ch === ',' && !inQuote) { cells.push(cur.trim()); cur = ''; }
        else cur += ch;
      }
      cells.push(cur.trim());
      const obj: any = {};
      headers.forEach((h, idx) => obj[h] = (cells[idx] || '').replace(/^"|"$/g, ''));
      if (obj.role && !['admin', 'guru', 'siswa'].includes(obj.role)) throw new Error(`Baris ${i + 1}: role "${obj.role}" tidak valid (harus: admin/guru/siswa)`);
      rows.push(obj as BulkUser);
    }
    return rows;
  }

  function onFile(e: React.ChangeEvent<HTMLInputElement>) {
    setBulkError(''); setBulkSuccess(''); setBulkPreview([]);
    const f = e.target.files?.[0];
    if (!f) return;
    const fname = f.name.toLowerCase();
    const isExcel = fname.endsWith('.xlsx') || fname.endsWith('.xls');

    if (isExcel) {
      // Read as ArrayBuffer for Excel
      const reader = new FileReader();
      reader.onload = () => {
        try {
          const rows = parseExcel(reader.result as ArrayBuffer);
          if (rows.length === 0) throw new Error('Tidak ada data yang bisa diimpor');
          for (let i = 0; i < rows.length; i++) {
            const r = rows[i];
            if (!r.username || !r.password || !r.name || !r.role)
              throw new Error(`Baris ${i + 2}: kolom username, password, name, dan role WAJIB diisi`);
          }
          setBulkPreview(rows);
        } catch (err: any) {
          setBulkError(err.message || 'Gagal memparsing file Excel');
          setBulkPreview([]);
        }
      };
      reader.readAsArrayBuffer(f);
    } else {
      // Read as text for CSV/JSON
      const reader = new FileReader();
      reader.onload = () => {
        try {
          const text = String(reader.result || '');
          let rows: BulkUser[] = [];
          if (fname.endsWith('.json')) {
            const data = JSON.parse(text);
            if (!Array.isArray(data)) throw new Error('File JSON harus berisi array');
            rows = data as BulkUser[];
          } else if (fname.endsWith('.csv')) {
            rows = parseCSV(text);
          } else {
            throw new Error('Format file tidak didukung. Gunakan .xlsx, .xls, .csv, atau .json');
          }
          if (rows.length === 0) throw new Error('Tidak ada data yang bisa diimpor');
          for (let i = 0; i < rows.length; i++) {
            const r = rows[i];
            if (!r.username || !r.password || !r.name || !r.role)
              throw new Error(`Baris ${i + 1}: kolom username, password, name, dan role WAJIB diisi`);
          }
          setBulkPreview(rows);
        } catch (err: any) {
          setBulkError(err.message || 'Gagal memparsing file');
          setBulkPreview([]);
        }
      };
      reader.readAsText(f);
    }
  }

  function importBulk() {
    if (bulkPreview.length === 0) return;
    const existing = usersStore.all();
    const existingUsernames = new Set(existing.map(u => u.username));
    const guruByUsername: Record<string, string> = {};
    existing.filter(u => u.role === 'guru').forEach(g => guruByUsername[g.username] = g.id);

    let added = 0; let skipped = 0;
    for (const row of bulkPreview) {
      if (existingUsernames.has(row.username)) { skipped++; continue; }
      const pembimbingId = row.pembimbingUsername ? guruByUsername[row.pembimbingUsername] : undefined;
      const newUser: User = {
        id: uid(),
        username: row.username,
        password: row.password,
        name: row.name,
        role: row.role,
        nip: row.nip,
        nis: row.nis,
        kelas: row.kelas,
        jurusan: row.jurusan,
        tempatPkl: row.tempatPkl,
        pembimbingId,
      };
      usersStore.add(newUser);
      // If this is a guru, update guruByUsername for subsequent rows
      if (newUser.role === 'guru') guruByUsername[newUser.username] = newUser.id;
      added++;
    }
    setBulkSuccess(`✅ Berhasil menambahkan ${added} pengguna. ${skipped > 0 ? `${skipped} dilewati (username sudah ada).` : ''}`);
    setBulkPreview([]);
    if (fileRef.current) fileRef.current.value = '';
    setTick(t => t + 1);
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between flex-wrap gap-3">
        <div>
          <h2 className="text-2xl font-bold text-slate-800">👥 Kelola Pengguna</h2>
          <p className="text-sm text-slate-500">Kelola akun Admin, Guru Pembimbing, dan Siswa. Tambah satu per satu atau impor massal via file Excel/CSV/JSON.</p>
        </div>
        <div className="flex gap-2 flex-wrap">
          <button onClick={() => setBulkOpen(true)} className="px-4 py-2 bg-blue-700 hover:bg-blue-800 text-white rounded-lg font-medium text-sm">📥 Impor Massal</button>
          <button onClick={() => setEditing(empty)} className="px-4 py-2 bg-emerald-700 hover:bg-emerald-800 text-white rounded-lg font-medium text-sm">➕ Tambah Pengguna</button>
        </div>
      </div>

      <div className="bg-white rounded-xl shadow p-5 border border-slate-200">
        <div className="flex items-center gap-2 mb-4 flex-wrap">
          {(['all', 'admin', 'guru', 'siswa'] as const).map(r => (
            <button key={r} onClick={() => setFilter(r)} className={`px-3 py-1.5 rounded-lg text-sm capitalize ${filter === r ? 'bg-emerald-700 text-white' : 'bg-slate-100 text-slate-700 hover:bg-slate-200'}`}>
              {r === 'all' ? 'Semua' : r}
            </button>
          ))}
          <div className="ml-auto text-sm text-slate-500">Total: {list.length}</div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead><tr className="bg-slate-100">
              <th className="border border-slate-300 px-3 py-2 w-12">No.</th>
              <th className="border border-slate-300 px-3 py-2">Nama</th>
              <th className="border border-slate-300 px-3 py-2">Username</th>
              <th className="border border-slate-300 px-3 py-2">Role</th>
              <th className="border border-slate-300 px-3 py-2">NIS/NIP</th>
              <th className="border border-slate-300 px-3 py-2">Kelas/Jurusan</th>
              <th className="border border-slate-300 px-3 py-2">Tempat PKL</th>
              <th className="border border-slate-300 px-3 py-2 w-28">Aksi</th>
            </tr></thead>
            <tbody>
              {list.map((u, i) => (
                <tr key={u.id}>
                  <td className="border border-slate-300 px-3 py-2 text-center">{i + 1}</td>
                  <td className="border border-slate-300 px-3 py-2 font-medium">{u.name}</td>
                  <td className="border border-slate-300 px-3 py-2 font-mono text-xs">{u.username}</td>
                  <td className="border border-slate-300 px-3 py-2 capitalize"><span className={`px-2 py-0.5 rounded-full text-xs ${u.role === 'admin' ? 'bg-rose-100 text-rose-700' : u.role === 'guru' ? 'bg-emerald-100 text-emerald-700' : 'bg-blue-100 text-blue-700'}`}>{u.role}</span></td>
                  <td className="border border-slate-300 px-3 py-2">{u.role === 'siswa' ? u.nis : u.nip}</td>
                  <td className="border border-slate-300 px-3 py-2">{u.role === 'siswa' ? `${u.kelas || '-'} / ${u.jurusan || '-'}` : '-'}</td>
                  <td className="border border-slate-300 px-3 py-2">{u.tempatPkl || '-'}</td>
                  <td className="border border-slate-300 px-3 py-2 text-center space-x-2 whitespace-nowrap">
                    <button onClick={() => setEditing(u)} className="text-blue-600 text-xs hover:underline">Edit</button>
                    <button onClick={() => remove(u.id)} className="text-rose-600 text-xs hover:underline">Hapus</button>
                  </td>
                </tr>
              ))}
              {list.length === 0 && <tr><td colSpan={8} className="border border-slate-300 px-3 py-10 text-center text-slate-400">Belum ada data</td></tr>}
            </tbody>
          </table>
        </div>
      </div>

      {/* Bulk Import Modal */}
      {bulkOpen && (
        <div className="fixed inset-0 bg-black/60 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-2xl shadow-2xl w-full max-w-4xl max-h-[92vh] overflow-y-auto">
            <div className="p-5 border-b border-slate-200 flex items-center justify-between sticky top-0 bg-white">
              <div>
                <h3 className="text-lg font-bold text-slate-800">📥 Impor Pengguna Massal</h3>
                <p className="text-sm text-slate-500">Upload file Excel (.xlsx), CSV, atau JSON berisi data pengguna</p>
              </div>
              <button onClick={() => { setBulkOpen(false); setBulkPreview([]); setBulkError(''); setBulkSuccess(''); }} className="text-slate-400 hover:text-slate-600 text-2xl leading-none">&times;</button>
            </div>
            <div className="p-5 space-y-5">
              {/* Template download */}
              <div className="bg-blue-50 border border-blue-200 rounded-xl p-4">
                <div className="font-semibold text-blue-900 mb-2">📄 Download Contoh Template</div>
                <p className="text-sm text-blue-800 mb-3">Silakan download contoh file, isi datanya, lalu upload kembali. Kolom <b>username, password, name, role</b> WAJIB diisi. Untuk siswa, isi <b>pembimbingUsername</b> dengan username guru pembimbingnya (guru harus ada di sistem atau diimpor dalam file yang sama).</p>
                <div className="flex gap-2 flex-wrap">
                  <button onClick={() => downloadTemplate('xlsx')} className="px-4 py-2 bg-emerald-700 hover:bg-emerald-800 text-white rounded-lg text-sm font-medium">📊 Download Template Excel (.xlsx)</button>
                  <button onClick={() => downloadTemplate('csv')} className="px-4 py-2 bg-blue-700 hover:bg-blue-800 text-white rounded-lg text-sm">📄 Template CSV</button>
                  <button onClick={() => downloadTemplate('json')} className="px-4 py-2 bg-slate-700 hover:bg-slate-800 text-white rounded-lg text-sm">📄 Template JSON</button>
                </div>
              </div>

              {/* Format info */}
              <div className="bg-slate-50 border border-slate-200 rounded-xl p-4 text-sm">
                <div className="font-semibold text-slate-800 mb-3">📋 Format Kolom (baris pertama = header):</div>
                <div className="overflow-x-auto mb-3">
                  <table className="text-xs border-collapse w-full">
                    <thead><tr className="bg-emerald-100">
                      <th className="border border-slate-300 px-2 py-1 text-left">Kolom</th>
                      <th className="border border-slate-300 px-2 py-1 text-left">Wajib</th>
                      <th className="border border-slate-300 px-2 py-1 text-left">Untuk</th>
                      <th className="border border-slate-300 px-2 py-1 text-left">Contoh Isi</th>
                    </tr></thead>
                    <tbody>
                      <tr><td className="border border-slate-300 px-2 py-1 font-mono font-bold">username</td><td className="border border-slate-300 px-2 py-1 text-rose-600 font-bold">Ya</td><td className="border border-slate-300 px-2 py-1">Semua</td><td className="border border-slate-300 px-2 py-1">siswa_001</td></tr>
                      <tr><td className="border border-slate-300 px-2 py-1 font-mono font-bold">password</td><td className="border border-slate-300 px-2 py-1 text-rose-600 font-bold">Ya</td><td className="border border-slate-300 px-2 py-1">Semua</td><td className="border border-slate-300 px-2 py-1">siswa123</td></tr>
                      <tr><td className="border border-slate-300 px-2 py-1 font-mono font-bold">name</td><td className="border border-slate-300 px-2 py-1 text-rose-600 font-bold">Ya</td><td className="border border-slate-300 px-2 py-1">Semua</td><td className="border border-slate-300 px-2 py-1">Ahmad Fauzi</td></tr>
                      <tr><td className="border border-slate-300 px-2 py-1 font-mono font-bold">role</td><td className="border border-slate-300 px-2 py-1 text-rose-600 font-bold">Ya</td><td className="border border-slate-300 px-2 py-1">Semua</td><td className="border border-slate-300 px-2 py-1">siswa / guru / admin</td></tr>
                      <tr><td className="border border-slate-300 px-2 py-1 font-mono">nip</td><td className="border border-slate-300 px-2 py-1 text-slate-500">-</td><td className="border border-slate-300 px-2 py-1">Guru</td><td className="border border-slate-300 px-2 py-1">198501012010012001</td></tr>
                      <tr><td className="border border-slate-300 px-2 py-1 font-mono">nis</td><td className="border border-slate-300 px-2 py-1 text-slate-500">-</td><td className="border border-slate-300 px-2 py-1">Siswa</td><td className="border border-slate-300 px-2 py-1">20240001</td></tr>
                      <tr><td className="border border-slate-300 px-2 py-1 font-mono">kelas</td><td className="border border-slate-300 px-2 py-1 text-slate-500">-</td><td className="border border-slate-300 px-2 py-1">Siswa</td><td className="border border-slate-300 px-2 py-1">XII TKJ 1</td></tr>
                      <tr><td className="border border-slate-300 px-2 py-1 font-mono">jurusan</td><td className="border border-slate-300 px-2 py-1 text-slate-500">-</td><td className="border border-slate-300 px-2 py-1">Siswa</td><td className="border border-slate-300 px-2 py-1">Teknik Komputer dan Jaringan</td></tr>
                      <tr><td className="border border-slate-300 px-2 py-1 font-mono">tempatPkl</td><td className="border border-slate-300 px-2 py-1 text-slate-500">-</td><td className="border border-slate-300 px-2 py-1">Siswa</td><td className="border border-slate-300 px-2 py-1">PT. Tech Nusantara</td></tr>
                      <tr><td className="border border-slate-300 px-2 py-1 font-mono">pembimbingUsername</td><td className="border border-slate-300 px-2 py-1 text-slate-500">-</td><td className="border border-slate-300 px-2 py-1">Siswa</td><td className="border border-slate-300 px-2 py-1">guru_budi</td></tr>
                    </tbody>
                  </table>
                </div>
                <div className="text-xs text-slate-600 space-y-1">
                  <div>📌 <b>Baris pertama</b> file Excel/CSV harus berisi <b>header kolom</b> persis seperti tabel di atas.</div>
                  <div>📌 Kolom <code className="bg-white px-1 rounded border">pembimbingUsername</code> diisi dengan <b>username</b> guru pembimbing (guru harus sudah ada atau diimpor dalam file yang sama).</div>
                  <div>📌 Username yang sudah ada di sistem akan <b>otomatis dilewati</b> (tidak akan terduplikasi).</div>
                </div>
              </div>

              {/* Upload */}
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-2">Upload File (Excel, CSV, atau JSON)</label>
                <input ref={fileRef} type="file" accept=".xlsx,.xls,.csv,.json" onChange={onFile} className="block w-full text-sm file:mr-4 file:py-2 file:px-4 file:rounded-lg file:border-0 file:bg-emerald-700 file:text-white hover:file:bg-emerald-800" />
                <p className="text-xs text-slate-500 mt-1">Format didukung: .xlsx (Excel), .xls, .csv, .json</p>
              </div>

              {bulkError && <div className="bg-rose-50 border border-rose-200 rounded-lg p-3 text-sm text-rose-700">❌ {bulkError}</div>}
              {bulkSuccess && <div className="bg-emerald-50 border border-emerald-200 rounded-lg p-3 text-sm text-emerald-700">{bulkSuccess}</div>}

              {/* Preview */}
              {bulkPreview.length > 0 && (
                <div>
                  <div className="font-semibold text-slate-800 mb-2 text-sm">👀 Preview ({bulkPreview.length} pengguna):</div>
                  <div className="overflow-x-auto border border-slate-200 rounded-lg max-h-72 overflow-y-auto">
                    <table className="w-full text-xs">
                      <thead className="bg-slate-100 sticky top-0"><tr>
                        <th className="border border-slate-300 px-2 py-1">Username</th>
                        <th className="border border-slate-300 px-2 py-1">Password</th>
                        <th className="border border-slate-300 px-2 py-1">Nama</th>
                        <th className="border border-slate-300 px-2 py-1">Role</th>
                        <th className="border border-slate-300 px-2 py-1">NIS/NIP</th>
                        <th className="border border-slate-300 px-2 py-1">Kelas/Jurusan</th>
                        <th className="border border-slate-300 px-2 py-1">Tempat PKL</th>
                        <th className="border border-slate-300 px-2 py-1">Pembimbing</th>
                      </tr></thead>
                      <tbody>
                        {bulkPreview.map((r, i) => (
                          <tr key={i}>
                            <td className="border border-slate-300 px-2 py-1 font-mono">{r.username}</td>
                            <td className="border border-slate-300 px-2 py-1">••••••</td>
                            <td className="border border-slate-300 px-2 py-1">{r.name}</td>
                            <td className="border border-slate-300 px-2 py-1 capitalize">{r.role}</td>
                            <td className="border border-slate-300 px-2 py-1">{r.role === 'siswa' ? r.nis : r.nip}</td>
                            <td className="border border-slate-300 px-2 py-1">{r.role === 'siswa' ? `${r.kelas || ''}/${r.jurusan || ''}` : '-'}</td>
                            <td className="border border-slate-300 px-2 py-1">{r.tempatPkl || '-'}</td>
                            <td className="border border-slate-300 px-2 py-1">{r.pembimbingUsername || '-'}</td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                  <div className="mt-3 flex justify-end gap-2">
                    <button onClick={() => setBulkPreview([])} className="px-4 py-2 bg-slate-100 hover:bg-slate-200 rounded-lg text-slate-700 text-sm">Batal</button>
                    <button onClick={importBulk} className="px-5 py-2 bg-emerald-700 hover:bg-emerald-800 text-white rounded-lg font-medium text-sm">💾 Impor Semua ({bulkPreview.length})</button>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* Edit Modal */}
      {editing && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-2xl shadow-2xl w-full max-w-2xl max-h-[90vh] overflow-y-auto">
            <div className="p-6 border-b border-slate-200 flex items-center justify-between">
              <h3 className="text-lg font-bold text-slate-800">{editing.id ? 'Edit' : 'Tambah'} Pengguna</h3>
              <button onClick={() => setEditing(null)} className="text-slate-400 hover:text-slate-600 text-2xl leading-none">&times;</button>
            </div>
            <form onSubmit={(e) => { e.preventDefault(); save(editing); }} className="p-6 space-y-3">
              <div className="grid md:grid-cols-2 gap-3">
                <Field label="Nama Lengkap" value={editing.name} onChange={v => setEditing({ ...editing, name: v })} required />
                <Field label="Username" value={editing.username} onChange={v => setEditing({ ...editing, username: v })} required />
                <Field label="Password" value={editing.password} onChange={v => setEditing({ ...editing, password: v })} required />
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1">Role</label>
                  <select value={editing.role} onChange={e => setEditing({ ...editing, role: e.target.value as Role })} className="w-full px-3 py-2 border border-slate-300 rounded-lg">
                    <option value="admin">Admin</option>
                    <option value="guru">Guru Pembimbing</option>
                    <option value="siswa">Siswa</option>
                  </select>
                </div>
                {editing.role === 'guru' && <Field label="NIP" value={editing.nip || ''} onChange={v => setEditing({ ...editing, nip: v })} />}
                {editing.role === 'siswa' && (
                  <>
                    <Field label="NIS" value={editing.nis || ''} onChange={v => setEditing({ ...editing, nis: v })} />
                    <Field label="Kelas" value={editing.kelas || ''} onChange={v => setEditing({ ...editing, kelas: v })} />
                    <Field label="Jurusan" value={editing.jurusan || ''} onChange={v => setEditing({ ...editing, jurusan: v })} />
                    <Field label="Tempat PKL" value={editing.tempatPkl || ''} onChange={v => setEditing({ ...editing, tempatPkl: v })} />
                    <div className="md:col-span-2">
                      <label className="block text-sm font-medium text-slate-700 mb-1">Guru Pembimbing</label>
                      <select value={editing.pembimbingId || ''} onChange={e => setEditing({ ...editing, pembimbingId: e.target.value })} className="w-full px-3 py-2 border border-slate-300 rounded-lg">
                        <option value="">-- Pilih Guru --</option>
                        {usersStore.byRole('guru').map(g => <option key={g.id} value={g.id}>{g.name}</option>)}
                      </select>
                    </div>
                  </>
                )}
              </div>
              <div className="flex justify-end gap-2 pt-3">
                <button type="button" onClick={() => setEditing(null)} className="px-4 py-2 bg-slate-100 hover:bg-slate-200 rounded-lg text-slate-700">Batal</button>
                <button type="submit" className="px-4 py-2 bg-emerald-700 hover:bg-emerald-800 text-white rounded-lg font-medium">Simpan</button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}

function Field({ label, value, onChange, required }: { label: string; value: string; onChange: (v: string) => void; required?: boolean; }) {
  return (
    <div>
      <label className="block text-sm font-medium text-slate-700 mb-1">{label}{required && ' *'}</label>
      <input value={value} onChange={e => onChange(e.target.value)} required={required} className="w-full px-3 py-2 border border-slate-300 rounded-lg" />
    </div>
  );
}

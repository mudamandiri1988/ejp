import { useState, useRef } from 'react';
import { User } from '../types';
import { signaturesStore, SignatureItem, uid, usersStore } from '../store';
import SignaturePad from '../components/SignaturePad';

interface Props { user: User; }

export default function SignatureManagePage({ user }: Props) {
  const [refresh, setRefresh] = useState(0);
  const [editing, setEditing] = useState<SignatureItem | null>(null);

  const list = signaturesStore.all();
  const guruSigs = list.filter(s => s.type === 'guru');
  const dudiSigs = list.filter(s => s.type === 'dudi');

  // For guru: only show their own guru signature + all dudi signatures
  const visibleGuru = user.role === 'admin' ? guruSigs : guruSigs.filter(s => s.ownerUserId === user.id);

  function startCreate(type: 'guru' | 'dudi') {
    setEditing({
      id: '',
      type,
      ownerUserId: type === 'guru' ? user.id : undefined,
      namaLengkap: type === 'guru' ? user.name : '',
      nbm: '',
      showNbm: true,
      jabatan: type === 'guru' ? 'Guru Pembimbing PKL' : 'Instruktur / Pembimbing DUDI',
      tempatPkl: '',
      signature: '',
      createdAt: new Date().toISOString(),
    });
  }

  function save(item: SignatureItem) {
    if (item.id) signaturesStore.update(item);
    else signaturesStore.add({ ...item, id: uid() });
    setEditing(null);
    setRefresh(r => r + 1);
  }

  function remove(id: string) {
    if (confirm('Hapus tanda tangan ini?')) { signaturesStore.remove(id); setRefresh(r => r + 1); }
  }

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold text-slate-800">✍️ Kelola Tanda Tangan</h2>
        <p className="text-sm text-slate-500">Kelola tanda tangan Guru Pembimbing & Instruktur DUDI. Keduanya akan muncul otomatis di bagian bawah lembar laporan PKL.</p>
      </div>

      <div className="grid md:grid-cols-2 gap-6">
        {/* GURU SIGNATURES */}
        <div className="bg-white rounded-xl shadow p-5 border border-slate-200">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h3 className="font-bold text-slate-800">👨‍🏫 Tanda Tangan Guru Pembimbing</h3>
              <p className="text-xs text-slate-500">Ditampilkan di setiap lembar laporan PKL</p>
            </div>
            {(user.role === 'admin' || (user.role === 'guru' && visibleGuru.length === 0)) && (
              <button onClick={() => startCreate('guru')} className="px-3 py-1.5 bg-emerald-700 hover:bg-emerald-800 text-white text-sm rounded-lg">➕ Tambah</button>
            )}
          </div>
          {visibleGuru.length === 0 ? (
            <div className="text-center py-8 text-slate-400 text-sm">Belum ada tanda tangan guru</div>
          ) : (
            <div className="space-y-3">
              {visibleGuru.map(s => (
                <SigCard key={s.id} item={s} onEdit={() => setEditing(s)} onRemove={() => remove(s.id)} />
              ))}
            </div>
          )}
        </div>

        {/* DUDI SIGNATURES */}
        <div className="bg-white rounded-xl shadow p-5 border border-slate-200">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h3 className="font-bold text-slate-800">🏢 Tanda Tangan Instruktur DUDI</h3>
              <p className="text-xs text-slate-500">Ditampilkan di setiap lembar laporan PKL</p>
            </div>
            <button onClick={() => startCreate('dudi')} className="px-3 py-1.5 bg-emerald-700 hover:bg-emerald-800 text-white text-sm rounded-lg">➕ Tambah</button>
          </div>
          {dudiSigs.length === 0 ? (
            <div className="text-center py-8 text-slate-400 text-sm">Belum ada tanda tangan instruktur DUDI</div>
          ) : (
            <div className="space-y-3">
              {dudiSigs.map(s => (
                <SigCard key={s.id} item={s} onEdit={() => setEditing(s)} onRemove={() => remove(s.id)} />
              ))}
            </div>
          )}
        </div>
      </div>

      <div className="bg-amber-50 border border-amber-200 rounded-xl p-4 text-sm text-amber-800">
        💡 <b>Catatan:</b> Siswa TIDAK perlu memasukkan nama Instruktur/DUDI — hal ini sudah di-input oleh Guru/Admin di halaman ini. Kedua tanda tangan akan muncul otomatis di bagian bawah lembar Daftar Hadir, Jurnal, Observasi, dan Catatan Kegiatan PKL.
      </div>

      {editing && (
        <SignatureEditorModal
          item={editing}
          onClose={() => { setEditing(null); }}
          onSave={save}
          user={user}
        />
      )}
      <div style={{ display: 'none' }}>{refresh}</div>
    </div>
  );
}

function SigCard({ item, onEdit, onRemove }: { item: SignatureItem; onEdit: () => void; onRemove: () => void; }) {
  return (
    <div className="border border-slate-200 rounded-lg p-3 flex items-start gap-3">
      <div className="border border-slate-200 bg-white rounded p-2 w-36 h-20 flex items-center justify-center shrink-0">
        {item.signature ? <img src={item.signature} alt="ttd" className="max-h-full object-contain" /> : <span className="text-xs text-slate-400">Belum ada tanda tangan</span>}
      </div>
      <div className="flex-1 min-w-0">
        <div className="font-semibold text-slate-800 text-sm">{item.namaLengkap}</div>
        <div className="text-xs text-slate-500">NBM: {item.nbm || '-'} {item.showNbm === false ? '(disembunyikan)' : '(ditampilkan)'}</div>
        {item.jabatan && <div className="text-xs text-slate-500">{item.jabatan}</div>}
        {item.tempatPkl && <div className="text-xs text-slate-500">🏢 {item.tempatPkl}</div>}
      </div>
      <div className="flex flex-col gap-1 shrink-0">
        <button onClick={onEdit} className="text-blue-600 text-xs hover:underline">Edit</button>
        <button onClick={onRemove} className="text-rose-600 text-xs hover:underline">Hapus</button>
      </div>
    </div>
  );
}

function SignatureEditorModal({ item, onClose, onSave, user }: { item: SignatureItem; onClose: () => void; onSave: (i: SignatureItem) => void; user: User; }) {
  const [form, setForm] = useState<SignatureItem>(item);
  const [uploadMode, setUploadMode] = useState(false);
  const fileRef = useRef<HTMLInputElement>(null);
  const guruUsers = usersStore.byRole('guru');

  function onFile(e: React.ChangeEvent<HTMLInputElement>) {
    const f = e.target.files?.[0];
    if (!f) return;
    const reader = new FileReader();
    reader.onload = () => setForm({ ...form, signature: reader.result as string });
    reader.readAsDataURL(f);
  }

  return (
    <div className="fixed inset-0 bg-black/60 flex items-center justify-center p-4 z-50">
      <div className="bg-white rounded-2xl shadow-2xl w-full max-w-2xl max-h-[92vh] overflow-y-auto">
        <div className="p-5 border-b border-slate-200 flex items-center justify-between sticky top-0 bg-white">
          <h3 className="text-lg font-bold text-slate-800">{form.id ? 'Edit' : 'Tambah'} Tanda Tangan {form.type === 'guru' ? 'Guru Pembimbing' : 'Instruktur DUDI'}</h3>
          <button onClick={onClose} className="text-slate-400 hover:text-slate-600 text-2xl leading-none">&times;</button>
        </div>
        <div className="p-5 space-y-4">
          <div className="grid md:grid-cols-2 gap-4">
            {form.type === 'guru' && user.role === 'admin' && (
              <div className="md:col-span-2">
                <label className="block text-sm font-medium text-slate-700 mb-1">Pemilik (Guru)</label>
                <select value={form.ownerUserId || ''} onChange={e => setForm({ ...form, ownerUserId: e.target.value })} className="w-full px-3 py-2 border border-slate-300 rounded-lg">
                  <option value="">-- Pilih Guru --</option>
                  {guruUsers.map(g => <option key={g.id} value={g.id}>{g.name}</option>)}
                </select>
              </div>
            )}
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-1">Nama Lengkap *</label>
              <input value={form.namaLengkap} onChange={e => setForm({ ...form, namaLengkap: e.target.value })} className="w-full px-3 py-2 border border-slate-300 rounded-lg" required />
            </div>
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-1">NBM *</label>
              <input value={form.nbm} onChange={e => setForm({ ...form, nbm: e.target.value })} className="w-full px-3 py-2 border border-slate-300 rounded-lg" placeholder="Nomor NBM" required />
            </div>
            <div className="md:col-span-2 bg-slate-50 border border-slate-200 rounded-lg p-3">
              <label className="flex items-start gap-3 text-sm text-slate-700 cursor-pointer">
                <input
                  type="checkbox"
                  checked={form.showNbm !== false}
                  onChange={e => setForm({ ...form, showNbm: e.target.checked })}
                  className="mt-1 h-4 w-4 rounded border-slate-300"
                />
                <span>
                  <b>Tampilkan NBM pada hasil cetak/PDF</b>
                  <span className="block text-xs text-slate-500 mt-1">Jika dimatikan, NBM tetap tersimpan di data tanda tangan tetapi tidak muncul di bagian tanda tangan laporan.</span>
                </span>
              </label>
            </div>
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-1">Jabatan</label>
              <input value={form.jabatan || ''} onChange={e => setForm({ ...form, jabatan: e.target.value })} className="w-full px-3 py-2 border border-slate-300 rounded-lg" />
            </div>
            {form.type === 'dudi' && (
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-1">Tempat PKL / Perusahaan</label>
                <input value={form.tempatPkl || ''} onChange={e => setForm({ ...form, tempatPkl: e.target.value })} className="w-full px-3 py-2 border border-slate-300 rounded-lg" />
              </div>
            )}
          </div>

          <div className="flex gap-2">
            <button onClick={() => setUploadMode(false)} className={`px-3 py-1.5 text-sm rounded-lg ${!uploadMode ? 'bg-emerald-700 text-white' : 'bg-slate-100 text-slate-700'}`}>✍️ Tulis Tanda Tangan</button>
            <button onClick={() => setUploadMode(true)} className={`px-3 py-1.5 text-sm rounded-lg ${uploadMode ? 'bg-emerald-700 text-white' : 'bg-slate-100 text-slate-700'}`}>📷 Upload Foto TTD</button>
          </div>

          {!uploadMode ? (
            <SignaturePad value={form.signature} onChange={(v) => setForm({ ...form, signature: v })} />
          ) : (
            <div className="space-y-2">
              <input ref={fileRef} type="file" accept="image/*" onChange={onFile} className="block w-full text-sm file:mr-4 file:py-2 file:px-4 file:rounded-lg file:border-0 file:bg-emerald-700 file:text-white" />
              {form.signature && <div className="border-2 border-dashed border-slate-300 rounded-lg p-4 bg-white text-center"><img src={form.signature} alt="ttd" className="h-32 mx-auto object-contain" /></div>}
            </div>
          )}

          <div className="flex justify-end gap-2 pt-2 border-t border-slate-200">
            <button onClick={onClose} className="px-4 py-2 bg-slate-100 hover:bg-slate-200 rounded-lg text-slate-700">Batal</button>
            <button onClick={() => onSave(form)} className="px-5 py-2 bg-emerald-700 hover:bg-emerald-800 text-white rounded-lg font-medium">💾 Simpan</button>
          </div>
        </div>
      </div>
    </div>
  );
}

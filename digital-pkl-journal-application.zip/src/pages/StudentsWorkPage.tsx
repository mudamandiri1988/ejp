import { useState, useRef } from 'react';
import { User } from '../types';
import { usersStore, attendanceStore, journalStore, observationStore, activityStore, signaturesStore, textCustomStore } from '../store';
import SheetHeader from '../components/SheetHeader';
import ExportPDFButton from '../components/ExportPDFButton';
import PrintButton from '../components/PrintButton';

interface Props { user: User; }

export default function StudentsWorkPage({ user }: Props) {
  const [selectedSiswa, setSelectedSiswa] = useState('');
  const sheetRef = useRef<HTMLDivElement>(null);

  const allSiswa = usersStore.byRole('siswa');
  const myStudents = user.role === 'guru' ? allSiswa.filter(s => s.pembimbingId === user.id) : allSiswa;
  const siswa = allSiswa.find(s => s.id === selectedSiswa);

  const attendance = attendanceStore.all().filter((e: any) => e.siswaId === selectedSiswa).sort((a: any, b: any) => a.tanggal.localeCompare(b.tanggal));
  const journal = journalStore.all().filter((e: any) => e.siswaId === selectedSiswa).sort((a: any, b: any) => a.tanggal.localeCompare(b.tanggal));
  const observation = observationStore.all().filter((e: any) => e.siswaId === selectedSiswa).sort((a: any, b: any) => a.tanggal.localeCompare(b.tanggal));
  const activity = activityStore.all().filter((e: any) => e.siswaId === selectedSiswa).sort((a: any, b: any) => a.tanggal.localeCompare(b.tanggal));

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between flex-wrap gap-3">
        <div>
          <h2 className="text-2xl font-bold text-slate-800">👀 Lihat Pekerjaan Siswa</h2>
          <p className="text-sm text-slate-500">Pilih siswa untuk melihat seluruh pekerjaan PKL & export PDF</p>
        </div>
        {siswa && (
          <div className="flex gap-2 flex-wrap">
            <ExportPDFButton targetRef={sheetRef as any} filename={`Lengkap-${siswa.name.replace(/\s+/g,'-')}.pdf`} label="📄 Export PDF Lengkap" />
            <PrintButton targetRef={sheetRef as any} title={`Laporan Lengkap PKL - ${siswa.name}`} label="🖨️ Cetak Lengkap" />
          </div>
        )}
      </div>

      <div className="bg-white rounded-xl shadow p-5 border border-slate-200">
        <div className="flex items-center gap-3 flex-wrap">
          <label className="text-sm font-medium text-slate-700">Pilih Siswa:</label>
          <select value={selectedSiswa} onChange={e => setSelectedSiswa(e.target.value)} className="px-3 py-2 border border-slate-300 rounded-lg text-sm min-w-[280px]">
            <option value="">-- Pilih Siswa --</option>
            {myStudents.map(s => <option key={s.id} value={s.id}>{s.name} ({s.kelas || '-'})</option>)}
          </select>
        </div>
      </div>

      {siswa && (
        <>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <StatCard label="Daftar Hadir" value={attendance.length} color="bg-blue-500" />
            <StatCard label="Jurnal Kegiatan" value={journal.length} color="bg-violet-500" />
            <StatCard label="Laporan Observasi" value={observation.length} color="bg-cyan-500" />
            <StatCard label="Catatan Kegiatan" value={activity.length} color="bg-indigo-500" />
          </div>

          <div ref={sheetRef} className="bg-white rounded-xl shadow p-8 border border-slate-200 space-y-10" style={{ minHeight: '297mm' }}>
            <SheetHeader title={textCustomStore.get().labelLengkap || 'LAPORAN LENGKAP PRAKTEK KERJA LAPANGAN'} subtitle={`Disusun oleh: ${siswa.name}`} siswa={siswa} />

            {/* Attendance */}
            <section>
              <h3 className="text-center text-lg font-bold bg-yellow-200 py-1.5 rounded mb-4">{textCustomStore.get().labelDaftarHadir || 'DAFTAR HADIR PESERTA PKL'}</h3>
              <table className="w-full text-sm border-collapse">
                <thead><tr className="bg-slate-100">
                  <th className="border border-slate-800 px-3 py-2 w-12">No.</th>
                  <th className="border border-slate-800 px-3 py-2 w-44">Hari, Tanggal</th>
                  <th className="border border-slate-800 px-3 py-2 w-28">Keterangan</th>
                  <th className="border border-slate-800 px-3 py-2">Tempat</th>
                  <th className="border border-slate-800 px-3 py-2 w-28">Datang</th>
                  <th className="border border-slate-800 px-3 py-2 w-28">Pulang</th>
                  <th className="border border-slate-800 px-3 py-2">Penjelasan</th>
                </tr></thead>
                <tbody>
                  {attendance.map((e: any, i: number) => (
                    <tr key={e.id} style={{ height: 40 }}>
                      <td className="border border-slate-800 px-3 py-2 text-center align-top">{i + 1}</td>
                      <td className="border border-slate-800 px-3 py-2 align-top">{new Date(e.tanggal).toLocaleDateString('id-ID', { weekday: 'long', day: '2-digit', month: 'long', year: 'numeric' })}</td>
                      <td className="border border-slate-800 px-3 py-2 text-center align-top">{e.statusKehadiran || 'Hadir'}</td>
                      <td className="border border-slate-800 px-3 py-2 align-top">{(e.statusKehadiran || 'Hadir') === 'Hadir' ? e.tempat : '-'}</td>
                      <td className="border border-slate-800 px-3 py-2 text-center align-top">{(e.statusKehadiran || 'Hadir') === 'Hadir' ? e.datangPukul : '-'}</td>
                      <td className="border border-slate-800 px-3 py-2 text-center align-top">{(e.statusKehadiran || 'Hadir') === 'Hadir' ? e.pulangPukul : '-'}</td>
                      <td className="border border-slate-800 px-3 py-2 align-top">{e.keteranganPenjelas || '-'}</td>
                    </tr>
                  ))}
                  {attendance.length === 0 && <tr><td colSpan={7} className="border border-slate-800 px-3 py-6 text-center text-slate-400">Belum ada data</td></tr>}
                </tbody>
              </table>
            </section>

            {/* Journal */}
            <section>
              <h3 className="text-center text-lg font-bold bg-yellow-200 py-1.5 rounded mb-4">{textCustomStore.get().labelJurnal || 'JURNAL KEGIATAN PKL'}</h3>
              <table className="w-full text-sm border-collapse">
                <thead><tr className="bg-slate-100">
                  <th className="border border-slate-800 px-3 py-2 w-12">No.</th>
                  <th className="border border-slate-800 px-3 py-2 w-40">Hari/Tanggal</th>
                  <th className="border border-slate-800 px-3 py-2">Unit Kerja</th>
                  <th className="border border-slate-800 px-3 py-2">Catatan</th>
                </tr></thead>
                <tbody>
                  {journal.map((e: any, i: number) => (
                    <tr key={e.id} style={{ height: 50 }}>
                      <td className="border border-slate-800 px-3 py-2 text-center align-top">{i + 1}</td>
                      <td className="border border-slate-800 px-3 py-2 align-top">{new Date(e.tanggal).toLocaleDateString('id-ID', { weekday: 'long', day: '2-digit', month: 'long', year: 'numeric' })}</td>
                      <td className="border border-slate-800 px-3 py-2 align-top">{e.unitKerja}</td>
                      <td className="border border-slate-800 px-3 py-2 align-top">{e.catatan}</td>
                    </tr>
                  ))}
                  {journal.length === 0 && <tr><td colSpan={4} className="border border-slate-800 px-3 py-6 text-center text-slate-400">Belum ada data</td></tr>}
                </tbody>
              </table>
            </section>

            {/* Observation */}
            <section>
              <h3 className="text-center text-lg font-bold bg-yellow-200 py-1.5 rounded mb-4">{textCustomStore.get().labelObservasi || 'LAPORAN HASIL OBSERVASI PKL'}</h3>
              <table className="w-full text-sm border-collapse">
                <thead><tr className="bg-slate-100">
                  <th className="border border-slate-800 px-3 py-2 w-32">Tanggal</th>
                  <th className="border border-slate-800 px-3 py-2">Kompetensi</th>
                  <th className="border border-slate-800 px-3 py-2">Indikator</th>
                  <th className="border border-slate-800 px-3 py-2">Catatan</th>
                  <th className="border border-slate-800 px-3 py-2 w-32">Paraf</th>
                </tr></thead>
                <tbody>
                  {observation.map((e: any) => (
                    <tr key={e.id} style={{ height: 50 }}>
                      <td className="border border-slate-800 px-3 py-2 align-top">{new Date(e.tanggal).toLocaleDateString('id-ID')}</td>
                      <td className="border border-slate-800 px-3 py-2 align-top">{e.kompetensi}</td>
                      <td className="border border-slate-800 px-3 py-2 align-top">{e.indikator}</td>
                      <td className="border border-slate-800 px-3 py-2 align-top">{e.catatan}</td>
                      <td className="border border-slate-800 px-3 py-2 align-top">{e.paraf}</td>
                    </tr>
                  ))}
                  {observation.length === 0 && <tr><td colSpan={5} className="border border-slate-800 px-3 py-6 text-center text-slate-400">Belum ada data</td></tr>}
                </tbody>
              </table>
            </section>

            {/* Activity */}
            <section>
              <h3 className="text-center text-lg font-bold bg-yellow-200 py-1.5 rounded mb-4">{textCustomStore.get().labelCatatan || 'CATATAN KEGIATAN PKL'}</h3>
              <div className="space-y-4">
                {activity.map((e: any, i: number) => (
                  <div key={e.id} className="border-2 border-slate-800 p-4 rounded">
                    <div className="font-bold mb-3">Kegiatan #{i + 1} — {new Date(e.tanggal).toLocaleDateString('id-ID', { weekday: 'long', day: '2-digit', month: 'long', year: 'numeric' })}</div>
                    <div className="space-y-2 text-sm">
                      <div><div className="font-semibold">A. Nama Pekerjaan</div><div className="border border-slate-800 p-2 min-h-8">{e.namaPekerjaan}</div></div>
                      <div><div className="font-semibold">B. Perencanaan Kegiatan</div><div className="border border-slate-800 p-2 min-h-12 whitespace-pre-wrap">{e.perencanaan}</div></div>
                      <div><div className="font-semibold">C. Pelaksanaan / Hasil</div><div className="border border-slate-800 p-2 min-h-16 whitespace-pre-wrap">{e.pelaksanaan}</div></div>
                      <div><div className="font-semibold">D. Catatan Instruktur</div><div className="border border-slate-800 p-2 min-h-12 whitespace-pre-wrap">{e.catatanInstruktur}</div></div>
                    </div>
                  </div>
                ))}
                {activity.length === 0 && <div className="border border-slate-800 p-8 text-center text-slate-400">Belum ada data</div>}
              </div>
            </section>

            <SignaturesFooter siswa={siswa || undefined} />
          </div>
        </>
      )}
    </div>
  );
}

function SignaturesFooter({ siswa }: { siswa?: User }) {
  const allSigs = signaturesStore.all();
  const guruSigs = allSigs.filter(s => s.type === 'guru');
  const dudiSigs = allSigs.filter(s => s.type === 'dudi');
  let guru = guruSigs.find(s => siswa?.pembimbingId && s.ownerUserId === siswa.pembimbingId);
  if (!guru && guruSigs.length > 0) guru = guruSigs[0];
  const dudi = dudiSigs[0];

  return (
    <div className="mt-10 pt-6 border-t border-slate-300">
      <div className="grid grid-cols-2 gap-8">
        <div className="text-center text-sm">
          <div className="font-semibold text-slate-800">Mengetahui,</div>
          <div className="font-semibold text-slate-800">{guru?.jabatan || 'Guru Pembimbing PKL'}</div>
          <div className="text-slate-600 text-xs mt-1">SMK Muhammadiyah 2 Playen</div>
          <div className="h-24 flex items-center justify-center my-2">
            {guru?.signature ? <img src={guru.signature} alt="ttd" className="h-20 object-contain" /> : <div className="text-xs text-slate-400 italic">(tanda tangan)</div>}
          </div>
          {guru && (<><div className="border-t border-slate-400 w-48 mx-auto"></div><div className="font-semibold text-slate-800 mt-1">{guru.namaLengkap}</div>{guru.showNbm !== false && <div className="text-xs text-slate-600">NBM. {guru.nbm || '-'}</div>}</>)}
        </div>
        <div className="text-center text-sm">
          <div className="font-semibold text-slate-800">Menyetujui,</div>
          <div className="font-semibold text-slate-800">{dudi?.jabatan || 'Instruktur / Pembimbing DUDI'}</div>
          <div className="text-slate-600 text-xs mt-1">{dudi?.tempatPkl || (siswa?.tempatPkl ? siswa.tempatPkl : 'Tempat PKL')}</div>
          <div className="h-24 flex items-center justify-center my-2">
            {dudi?.signature ? <img src={dudi.signature} alt="ttd" className="h-20 object-contain" /> : <div className="text-xs text-slate-400 italic">(tanda tangan)</div>}
          </div>
          {dudi && (<><div className="border-t border-slate-400 w-48 mx-auto"></div><div className="font-semibold text-slate-800 mt-1">{dudi.namaLengkap}</div>{dudi.showNbm !== false && <div className="text-xs text-slate-600">NBM. {dudi.nbm || '-'}</div>}</>)}
        </div>
      </div>
    </div>
  );
}

function StatCard({ label, value, color }: { label: string; value: number; color: string; }) {
  return (
    <div className={`${color} text-white rounded-xl p-4 shadow`}>
      <div className="text-3xl font-bold">{value}</div>
      <div className="text-sm text-white/90 mt-1">{label}</div>
    </div>
  );
}

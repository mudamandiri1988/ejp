import { useState, useRef } from 'react';
import { User } from '../types';
import { usersStore } from '../store';
import SignaturePad from '../components/SignaturePad';

interface Props { user: User; onUpdate: (u: User) => void; }

export default function SignaturePage({ user, onUpdate }: Props) {
  const [sig, setSig] = useState(user.signature || '');
  const [uploadMode, setUploadMode] = useState(false);
  const fileRef = useRef<HTMLInputElement>(null);

  function save() {
    const updated = { ...user, signature: sig };
    usersStore.update(updated);
    onUpdate(updated);
    alert('Tanda tangan berhasil disimpan!');
  }

  function onFile(e: React.ChangeEvent<HTMLInputElement>) {
    const f = e.target.files?.[0];
    if (!f) return;
    const reader = new FileReader();
    reader.onload = () => setSig(reader.result as string);
    reader.readAsDataURL(f);
  }

  return (
    <div className="space-y-6 max-w-3xl">
      <div>
        <h2 className="text-2xl font-bold text-slate-800">✍️ Tanda Tangan Digital</h2>
        <p className="text-sm text-slate-500">Tanda tangan akan ditampilkan pada lembar laporan & monitoring yang diexport PDF</p>
      </div>

      <div className="bg-white rounded-xl shadow p-6 border border-slate-200">
        <div className="flex items-center justify-between mb-4">
          <div>
            <div className="font-semibold text-slate-800">{user.name}</div>
            <div className="text-xs text-slate-500 capitalize">{user.role === 'admin' ? 'Administrator' : user.role === 'guru' ? 'Guru Pembimbing' : 'Siswa'}</div>
          </div>
          <div className="flex gap-2">
            <button onClick={() => setUploadMode(false)} className={`px-3 py-1.5 text-sm rounded-lg ${!uploadMode ? 'bg-emerald-700 text-white' : 'bg-slate-100 text-slate-700'}`}>✍️ Tulis</button>
            <button onClick={() => setUploadMode(true)} className={`px-3 py-1.5 text-sm rounded-lg ${uploadMode ? 'bg-emerald-700 text-white' : 'bg-slate-100 text-slate-700'}`}>📷 Upload Foto</button>
          </div>
        </div>

        {!uploadMode ? (
          <SignaturePad value={sig} onChange={setSig} />
        ) : (
          <div className="space-y-3">
            <label className="block text-sm font-medium text-slate-700">Upload foto tanda tangan (PNG/JPG transparan putih)</label>
            <input ref={fileRef} type="file" accept="image/*" onChange={onFile} className="block w-full text-sm text-slate-700 file:mr-4 file:py-2 file:px-4 file:rounded-lg file:border-0 file:bg-emerald-700 file:text-white hover:file:bg-emerald-800" />
            {sig && <div className="border-2 border-dashed border-slate-300 rounded-lg p-4 bg-white text-center"><img src={sig} alt="tanda tangan" className="h-32 mx-auto object-contain" /></div>}
          </div>
        )}

        <div className="mt-6 flex gap-2">
          <button onClick={save} className="px-5 py-2 bg-emerald-700 hover:bg-emerald-800 text-white rounded-lg font-medium">💾 Simpan Tanda Tangan</button>
          <button onClick={() => { setSig(''); const u = { ...user, signature: '' }; usersStore.update(u); onUpdate(u); }} className="px-4 py-2 bg-slate-100 hover:bg-slate-200 rounded-lg text-slate-700">Hapus</button>
        </div>
      </div>

      <div className="bg-amber-50 border border-amber-200 rounded-xl p-4 text-sm text-amber-800">
        💡 <b>Catatan:</b> Tanda tangan ini akan muncul di setiap lembar laporan PDF yang Anda buat. Pastikan tanda tangan jelas dan terbaca.
      </div>
    </div>
  );
}

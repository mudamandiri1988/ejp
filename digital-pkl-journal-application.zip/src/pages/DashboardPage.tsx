import { User } from '../types';
import { usersStore, monitoringStore, attendanceStore, journalStore, observationStore, activityStore, settingsStore } from '../store';
import { useTheme } from '../components/ThemeProvider';

interface Props { user: User; onNavigate: (p: string) => void; }

export default function DashboardPage({ user, onNavigate }: Props) {
  const theme = useTheme().theme;
  const settings = settingsStore.get();
  const users = usersStore.all();
  const siswaCount = users.filter(u => u.role === 'siswa').length;
  const guruCount = users.filter(u => u.role === 'guru').length;
  const myStudents = user.role === 'guru' ? users.filter(u => u.pembimbingId === user.id) : [];

  const countFor = (store: { all: () => any[] }) => {
    const all = store.all();
    if (user.role === 'siswa') return all.filter(x => x.siswaId === user.id).length;
    if (user.role === 'guru') {
      if (store === monitoringStore) return all.filter(x => x.guruId === user.id).length;
      const ids = myStudents.map(s => s.id);
      return all.filter(x => ids.includes(x.siswaId)).length;
    }
    return all.length;
  };

  const cards = [
    { label: 'Siswa Terdaftar', value: siswaCount, color: 'from-blue-500 to-blue-700', icon: '👨‍🎓' },
    { label: 'Guru Pembimbing', value: guruCount, color: 'from-emerald-500 to-emerald-700', icon: '👨‍🏫' },
    { label: 'Catatan Monitoring', value: countFor(monitoringStore), color: 'from-amber-500 to-amber-700', icon: '📋' },
    { label: 'Daftar Hadir', value: countFor(attendanceStore), color: 'from-rose-500 to-rose-700', icon: '📝' },
    { label: 'Jurnal Kegiatan', value: countFor(journalStore), color: 'from-violet-500 to-violet-700', icon: '📓' },
    { label: 'Laporan Observasi', value: countFor(observationStore), color: 'from-cyan-500 to-cyan-700', icon: '🔍' },
    { label: 'Catatan Kegiatan', value: countFor(activityStore), color: 'from-indigo-500 to-indigo-700', icon: '📑' },
  ];

  return (
    <div className="space-y-6">
      <div className={`bg-gradient-to-r ${theme.primary} ${theme.primary2} text-white rounded-2xl p-6 sm:p-8 shadow-lg`}>
        <div className="flex flex-col gap-4 lg:flex-row lg:items-start lg:justify-between">
          <div>
            <h2 className="text-2xl font-bold">Selamat datang, {user.name}! 👋</h2>
            <p className="mt-2 text-white/85">
          {user.role === 'admin' && 'Kelola pengguna, monitoring, dan seluruh laporan PKL dari satu dashboard.'}
          {user.role === 'guru' && `Anda membimbing ${myStudents.length} siswa. Kelola monitoring dan lihat pekerjaan siswa.`}
          {user.role === 'siswa' && 'Isi daftar hadir, jurnal kegiatan, dan laporan PKL Anda secara rutin.'}
            </p>
          </div>
          <div className="rounded-xl bg-white/15 px-4 py-3 backdrop-blur-sm lg:min-w-72">
            <div className="text-xs font-semibold uppercase tracking-wider text-white/70">Jurusan Aktif PKL</div>
            <div className="mt-1 text-lg font-bold leading-snug text-white">{settings.jurusanAktif || '-'}</div>
            {user.role === 'admin' && <div className="mt-1 text-xs text-white/70">Ubah nama jurusan di menu Pengaturan.</div>}
          </div>
        </div>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
        {cards.map((c, i) => (
          <div key={i} className={`bg-gradient-to-br ${c.color} text-white rounded-xl p-5 shadow`}>
            <div className="text-3xl">{c.icon}</div>
            <div className="mt-3 text-3xl font-bold">{c.value}</div>
            <div className="text-sm text-white/90 mt-1">{c.label}</div>
          </div>
        ))}
      </div>

      <div className="grid md:grid-cols-2 gap-6">
        <div className="bg-white rounded-xl shadow p-6 border border-slate-200">
          <h3 className="font-bold text-slate-800 mb-4">📌 Panduan Singkat</h3>
          <ul className="space-y-2 text-sm text-slate-600">
            {user.role === 'admin' && (
              <>
                <li>• Kelola akun siswa, guru, dan admin di menu <b>Kelola Pengguna</b></li>
                <li>• Upload tanda tangan di menu <b>Tanda Tangan</b></li>
                <li>• Pantau seluruh catatan dan laporan PKL</li>
              </>
            )}
            {user.role === 'guru' && (
              <>
                <li>• Isi <b>CATATAN MONITORING GURU PEMBIMBING</b> secara rutin</li>
                <li>• Upload tanda tangan di menu <b>Tanda Tangan</b></li>
                <li>• Lihat & export PDF pekerjaan siswa di menu <b>Lihat Pekerjaan Siswa</b></li>
              </>
            )}
            {user.role === 'siswa' && (
              <>
                <li>• Isi <b>DAFTAR HADIR PKL</b> setiap hari</li>
                <li>• Tulis <b>JURNAL KEGIATAN PKL</b> secara rutin</li>
                <li>• Lengkapi <b>LAPORAN OBSERVASI</b> & <b>CATATAN KEGIATAN</b></li>
              </>
            )}
          </ul>
        </div>

        <div className="bg-white rounded-xl shadow p-6 border border-slate-200">
          <h3 className="font-bold text-slate-800 mb-4">🚀 Menu Cepat</h3>
          <div className="grid grid-cols-2 gap-2">
            {(user.role === 'admin'
              ? [['Kelola Pengguna','users','👥'],['Monitoring','monitoring','📋'],['Tanda Tangan','signature','✍️'],['Jurnal','journal','📓']]
              : user.role === 'guru'
              ? [['Monitoring','monitoring','📋'],['Pekerjaan Siswa','students-work','👀'],['Tanda Tangan','signature','✍️'],['Dashboard','dashboard','🏠']]
              : [['Daftar Hadir','attendance','📝'],['Jurnal','journal','📓'],['Observasi','observation','🔍'],['Catatan','activity','📑']]
            ).map(([label, page, icon]: any) => (
              <button key={page} onClick={() => onNavigate(page)} className="flex items-center gap-2 p-3 rounded-lg bg-slate-50 hover:bg-emerald-50 border border-slate-200 hover:border-emerald-300 text-sm text-slate-700">
                <span>{icon}</span>{label}
              </button>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}

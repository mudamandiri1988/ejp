import { useState, useMemo, useRef } from 'react';
import { User, MonitoringEntry } from '../types';
import { usersStore, monitoringStore, uid, textCustomStore, signaturesStore } from '../store';
import SheetHeader from '../components/SheetHeader';
import ExportPDFButton from '../components/ExportPDFButton';
import PrintButton from '../components/PrintButton';

interface Props { user: User; }

export default function MonitoringPage({ user }: Props) {
  const [refresh, setRefresh] = useState(0);
  const [form, setForm] = useState({ siswaId: '', tanggal: new Date().toISOString().slice(0, 10), catatan: '' });
  const [filterSiswa, setFilterSiswa] = useState('');
  const sheetRef = useRef<HTMLDivElement>(null);

  const allSiswa = usersStore.byRole('siswa');
  const myStudents = user.role === 'guru' ? allSiswa.filter(s => s.pembimbingId === user.id) : allSiswa;
  void signaturesStore;
  const allEntries = monitoringStore.all();
  const entries = useMemo(() => {
    let list = allEntries;
    if (user.role === 'guru') list = list.filter(e => e.guruId === user.id);
    if (filterSiswa) list = list.filter(e => e.siswaId === filterSiswa);
    return list.sort((a, b) => a.tanggal.localeCompare(b.tanggal));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [allEntries, user.id, filterSiswa, refresh]);

  function addEntry(e: React.FormEvent) {
    e.preventDefault();
    if (!form.siswaId || !form.tanggal || !form.catatan) return;
    monitoringStore.add({ id: uid(), guruId: user.id, ...form } as MonitoringEntry);
    setForm({ siswaId: '', tanggal: new Date().toISOString().slice(0, 10), catatan: '' });
    setRefresh(r => r + 1);
  }

  function remove(id: string) {
    if (confirm('Hapus catatan ini?')) { monitoringStore.remove(id); setRefresh(r => r + 1); }
  }

  const grouped = useMemo(() => {
    const g: Record<string, { siswa: User; entries: MonitoringEntry[] }> = {};
    for (const e of entries) {
      if (!g[e.siswaId]) {
        const s = usersStore.all().find(u => u.id === e.siswaId);
        if (s) g[e.siswaId] = { siswa: s, entries: [] };
      }
      if (g[e.siswaId]) g[e.siswaId].entries.push(e);
    }
    return Object.values(g);
  }, [entries]);

  return (
    <div className="space-y-6">
      <div className="flex items-start justify-between gap-3 flex-wrap">
        <div>
          <h2 className="text-2xl font-bold text-slate-800">Catatan Monitoring Guru Pembimbing</h2>
          <p className="text-sm text-slate-500">Isi catatan monitoring secara rutin untuk setiap siswa</p>
        </div>
        {grouped.length > 0 && (
          <div className="flex gap-2 flex-wrap">
            <ExportPDFButton
              targetRef={sheetRef as any}
              filename={`Catatan-Monitoring-Guru-Pembimbing-${new Date().toISOString().slice(0,10)}.pdf`}
              label="📄 Download PDF"
            />
            <PrintButton
              targetRef={sheetRef as any}
              title={textCustomStore.get().labelMonitoring || 'CATATAN MONITORING GURU PEMBIMBING'}
              label="🖨️ Cetak"
            />
          </div>
        )}
      </div>

      {user.role !== 'siswa' && (
        <form onSubmit={addEntry} className="bg-white rounded-xl shadow p-5 border border-slate-200">
          <h3 className="font-semibold text-slate-800 mb-4">➕ Tambah Catatan Monitoring</h3>
          <div className="grid md:grid-cols-3 gap-4">
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-1">Siswa</label>
              <select value={form.siswaId} onChange={e => setForm({ ...form, siswaId: e.target.value })} className="w-full px-3 py-2 border border-slate-300 rounded-lg">
                <option value="">-- Pilih Siswa --</option>
                {myStudents.map(s => <option key={s.id} value={s.id}>{s.name} ({s.kelas})</option>)}
              </select>
            </div>
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-1">Hari, Tanggal</label>
              <input type="date" value={form.tanggal} onChange={e => setForm({ ...form, tanggal: e.target.value })} className="w-full px-3 py-2 border border-slate-300 rounded-lg" />
            </div>
            <div className="md:col-span-3">
              <label className="block text-sm font-medium text-slate-700 mb-1">Catatan Guru Pembimbing</label>
              <textarea value={form.catatan} onChange={e => setForm({ ...form, catatan: e.target.value })} rows={3} className="w-full px-3 py-2 border border-slate-300 rounded-lg" placeholder="Tulis catatan monitoring..." />
            </div>
          </div>
          <div className="mt-4">
            <button type="submit" className="px-5 py-2 bg-emerald-700 hover:bg-emerald-800 text-white rounded-lg font-medium">Simpan Catatan</button>
          </div>
        </form>
      )}

      <div className="bg-white rounded-xl shadow p-5 border border-slate-200">
        <div className="flex flex-wrap items-center gap-3 mb-4">
          <label className="text-sm font-medium text-slate-700">Filter Siswa:</label>
          <select value={filterSiswa} onChange={e => setFilterSiswa(e.target.value)} className="px-3 py-1.5 border border-slate-300 rounded-lg text-sm">
            <option value="">Semua Siswa</option>
            {myStudents.map(s => <option key={s.id} value={s.id}>{s.name}</option>)}
          </select>
          <div className="ml-auto flex gap-2 flex-wrap">
            {grouped.length > 0 ? (
              <>
                <ExportPDFButton
                  targetRef={sheetRef as any}
                  filename={`Catatan-Monitoring-Guru-Pembimbing-${filterSiswa ? (myStudents.find(s => s.id === filterSiswa)?.name || 'Siswa').replace(/\s+/g, '-') : 'Semua'}-${new Date().toISOString().slice(0,10)}.pdf`}
                  label="📄 Download PDF"
                  className="inline-flex items-center gap-2 px-3 py-1.5 bg-rose-600 hover:bg-rose-700 text-white text-xs font-medium rounded-lg shadow-sm"
                />
                <PrintButton
                  targetRef={sheetRef as any}
                  title={textCustomStore.get().labelMonitoring || 'CATATAN MONITORING GURU PEMBIMBING'}
                  label="🖨️ Cetak"
                  className="inline-flex items-center gap-2 px-3 py-1.5 bg-blue-700 hover:bg-blue-800 text-white text-xs font-medium rounded-lg shadow-sm"
                />
              </>
            ) : (
              <span className="text-xs text-slate-400 self-center">Cetak/PDF aktif setelah ada data monitoring</span>
            )}
          </div>
        </div>

        {entries.length === 0 ? (
          <div className="text-center py-12 text-slate-400">Belum ada catatan monitoring</div>
        ) : (
          <table className="w-full text-sm">
            <thead>
              <tr className="bg-slate-100">
                <th className="border border-slate-300 px-3 py-2 w-12">No.</th>
                <th className="border border-slate-300 px-3 py-2">Siswa</th>
                <th className="border border-slate-300 px-3 py-2 w-40">Hari, Tanggal</th>
                <th className="border border-slate-300 px-3 py-2">Catatan Guru Pembimbing</th>
                <th className="border border-slate-300 px-3 py-2 w-32">Tanda Tangan</th>
                {user.role !== 'siswa' && <th className="border border-slate-300 px-3 py-2 w-20">Aksi</th>}
              </tr>
            </thead>
            <tbody>
              {entries.map((e, i) => {
                const s = usersStore.all().find(u => u.id === e.siswaId);
                return (
                  <tr key={e.id}>
                    <td className="border border-slate-300 px-3 py-2 text-center">{i + 1}</td>
                    <td className="border border-slate-300 px-3 py-2">{s?.name || '-'}</td>
                    <td className="border border-slate-300 px-3 py-2">{new Date(e.tanggal).toLocaleDateString('id-ID', { weekday: 'long', day: '2-digit', month: 'long', year: 'numeric' })}</td>
                    <td className="border border-slate-300 px-3 py-2">{e.catatan}</td>
                    <td className="border border-slate-300 px-3 py-2">
                      {user.signature ? <img src={user.signature} className="h-10 mx-auto" alt="sig" /> : <span className="text-xs text-slate-400 text-center block">Belum upload</span>}
                    </td>
                    {user.role !== 'siswa' && <td className="border border-slate-300 px-3 py-2 text-center"><button onClick={() => remove(e.id)} className="text-rose-600 text-xs hover:underline">Hapus</button></td>}
                  </tr>
                );
              })}
            </tbody>
          </table>
        )}
      </div>

      {/* Printable Sheet */}
      {grouped.length > 0 && (
        <div ref={sheetRef} className="bg-white rounded-xl shadow p-8 border border-slate-200" style={{ minHeight: '297mm' }}>
          {grouped.map((g, gi) => (
            <div key={gi} className={gi > 0 ? 'mt-10 pt-6 border-t-2 border-slate-300' : ''}>
               <SheetHeader title={textCustomStore.get().labelMonitoring || 'CATATAN MONITORING GURU PEMBIMBING'} siswa={g.siswa} />
              <table className="w-full text-sm border-collapse">
                <thead>
                  <tr className="bg-slate-100">
                    <th className="border border-slate-800 px-3 py-2 w-12">No.</th>
                    <th className="border border-slate-800 px-3 py-2 w-40">Hari, Tanggal</th>
                    <th className="border border-slate-800 px-3 py-2">Catatan Guru Pembimbing</th>
                    <th className="border border-slate-800 px-3 py-2 w-40">Tanda Tangan</th>
                  </tr>
                </thead>
                <tbody>
                  {g.entries.map((e, i) => (
                    <tr key={e.id} style={{ height: 50 }}>
                      <td className="border border-slate-800 px-3 py-2 text-center align-top">{i + 1}</td>
                      <td className="border border-slate-800 px-3 py-2 align-top">{new Date(e.tanggal).toLocaleDateString('id-ID', { weekday: 'long', day: '2-digit', month: 'long', year: 'numeric' })}</td>
                      <td className="border border-slate-800 px-3 py-2 align-top">{e.catatan}</td>
                      <td className="border border-slate-800 px-3 py-2 align-top">
                        {user.signature ? <img src={user.signature} className="h-12" alt="sig" /> : ''}
                      </td>
                    </tr>
                  ))}
                  {Array.from({ length: Math.max(0, 5 - g.entries.length) }).map((_, i) => (
                    <tr key={'empty-' + i} style={{ height: 50 }}>
                      <td className="border border-slate-800 px-3 py-2"></td>
                      <td className="border border-slate-800 px-3 py-2"></td>
                      <td className="border border-slate-800 px-3 py-2"></td>
                      <td className="border border-slate-800 px-3 py-2"></td>
                    </tr>
                  ))}
                </tbody>
              </table>
              <div className="flex justify-end mt-8">
                <div className="text-center text-sm">
                  Playen, {new Date().toLocaleDateString('id-ID', { day: '2-digit', month: 'long', year: 'numeric' })}<br/>
                  Guru Pembimbing<br/><br/><br/>
                  <u>{user.name}</u><br/>
                  NIP. {user.nip || '-'}
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

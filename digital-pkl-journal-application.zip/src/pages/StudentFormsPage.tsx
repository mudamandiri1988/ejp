import { useState, useMemo, useRef, useEffect } from 'react';
import { User, JournalEntry, ObservationEntry, ActivityEntry, AttendanceEntry } from '../types';
import { usersStore, attendanceStore, journalStore, observationStore, activityStore, settingsStore, uid, signaturesStore, textCustomStore } from '../store';
import SheetHeader from '../components/SheetHeader';
import ExportPDFButton from '../components/ExportPDFButton';
import PrintButton from '../components/PrintButton';
import SignaturePad from '../components/SignaturePad';

type FormType = 'attendance' | 'journal' | 'observation' | 'activity';

interface Props { user: User; type: FormType; }

const config: Record<FormType, { title: string; desc: string; icon: string; sheetTitleKey: keyof import('../store').TextCustom; sheetTitleFallback: string }> = {
  attendance: { title: 'Daftar Hadir PKL', desc: 'Isi daftar hadir dengan pilihan Hadir, Sakit, atau Ijin setiap hari', icon: '📍', sheetTitleKey: 'labelDaftarHadir', sheetTitleFallback: 'DAFTAR HADIR PESERTA PKL' },
  journal: { title: 'Jurnal Kegiatan PKL', desc: 'Tulis jurnal kegiatan harian selama PKL', icon: '📓', sheetTitleKey: 'labelJurnal', sheetTitleFallback: 'JURNAL KEGIATAN PKL' },
  observation: { title: 'Laporan Hasil Observasi PKL', desc: 'Laporkan hasil observasi kompetensi PKL', icon: '🔍', sheetTitleKey: 'labelObservasi', sheetTitleFallback: 'LAPORAN HASIL OBSERVASI PKL' },
  activity: { title: 'Catatan Kegiatan PKL', desc: 'Dokumentasikan pekerjaan, perencanaan, dan hasil', icon: '📑', sheetTitleKey: 'labelCatatan', sheetTitleFallback: 'CATATAN KEGIATAN PKL' },
};

function isWithinTime(start: string, end: string) {
  const now = new Date();
  const cur = now.getHours() * 60 + now.getMinutes();
  const [sh, sm] = start.split(':').map(Number);
  const [eh, em] = end.split(':').map(Number);
  const s = sh * 60 + sm;
  const e = eh * 60 + em;
  return cur >= s && cur <= e;
}

export default function StudentFormsPage({ user, type }: Props) {
  const [refresh, setRefresh] = useState(0);
  const sheetRef = useRef<HTMLDivElement>(null);
  const [selectedSiswa, setSelectedSiswa] = useState(user.role === 'siswa' ? user.id : '');
  const [editing, setEditing] = useState<string | null>(null);
  const [signingId, setSigningId] = useState<string | null>(null);
  const [, setTick] = useState(0);

  // Tick every 30s to update "within time" status
  useEffect(() => {
    const t = setInterval(() => setTick(x => x + 1), 30000);
    return () => clearInterval(t);
  }, []);

  const store = type === 'attendance' ? attendanceStore : type === 'journal' ? journalStore : type === 'observation' ? observationStore : activityStore;

  const allSiswa = usersStore.byRole('siswa');
  const allEntries: any[] = store.all();
  const entries: any[] = useMemo(() => {
    let list = allEntries;
    if (user.role === 'siswa') list = list.filter((e: any) => e.siswaId === user.id);
    else if (selectedSiswa) list = list.filter((e: any) => e.siswaId === selectedSiswa);
    return list.sort((a: any, b: any) => (b.waktuIsi || b.tanggal).localeCompare(a.waktuIsi || a.tanggal));
  }, [allEntries, user.id, selectedSiswa, refresh]);

  const activeSiswa = user.role === 'siswa' ? user : allSiswa.find(s => s.id === selectedSiswa);

  function remove(id: string) {
    if (confirm('Hapus data ini?')) { store.remove(id); setRefresh(r => r + 1); }
  }

  const cfg = config[type];
  const settings = settingsStore.get();
  const withinTime = isWithinTime(settings.startHour, settings.endHour);

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between flex-wrap gap-3">
        <div>
          <h2 className="text-2xl font-bold text-slate-800">{cfg.icon} {cfg.title}</h2>
          <p className="text-sm text-slate-500">{cfg.desc}</p>
        </div>
        {entries.length > 0 && activeSiswa && (
          <div className="flex gap-2 flex-wrap">
            <ExportPDFButton targetRef={sheetRef as any} filename={`${cfg.title}-${(activeSiswa?.name||'').replace(/\s+/g,'-')}-${new Date().toISOString().slice(0,10)}.pdf`} />
            <PrintButton targetRef={sheetRef as any} title={`${cfg.title} - ${activeSiswa?.name || ''}`} />
          </div>
        )}
      </div>

      {type === 'attendance' && (
        <div className={`rounded-xl p-4 border-2 ${withinTime ? 'bg-emerald-50 border-emerald-300' : 'bg-rose-50 border-rose-300'}`}>
          <div className="flex items-center gap-3 flex-wrap">
            <div className="text-3xl">{withinTime ? '✅' : '🔒'}</div>
            <div>
              <div className={`font-bold ${withinTime ? 'text-emerald-800' : 'text-rose-800'}`}>
                {withinTime ? 'Presensi DIBUKA' : 'Presensi DITUTUP'}
              </div>
              <div className="text-sm text-slate-700">
                Jam operasional: <b>{settings.startHour}</b> - <b>{settings.endHour}</b> WIB • Toleransi keterlambatan: <b>{settings.toleranceMinutes} menit</b>
              </div>
              <div className="text-xs text-slate-500 mt-1">
                Waktu sekarang: {new Date().toLocaleTimeString('id-ID')}
              </div>
            </div>
            {user.role === 'admin' && <span className="ml-auto text-xs text-slate-500">Ubah jam di menu ⚙️ Pengaturan</span>}
          </div>
        </div>
      )}

      {user.role !== 'siswa' && (
        <div className="bg-white rounded-xl shadow p-4 border border-slate-200 flex items-center gap-3 flex-wrap">
          <label className="text-sm font-medium text-slate-700">Pilih Siswa:</label>
          <select value={selectedSiswa} onChange={e => setSelectedSiswa(e.target.value)} className="px-3 py-2 border border-slate-300 rounded-lg text-sm">
            <option value="">-- Pilih Siswa --</option>
            {allSiswa.map(s => <option key={s.id} value={s.id}>{s.name} ({s.kelas})</option>)}
          </select>
          {!selectedSiswa && <span className="text-xs text-slate-400">Pilih siswa untuk melihat data</span>}
        </div>
      )}

      {(user.role === 'siswa' || selectedSiswa) && (
        <>
          {type === 'attendance' ? (
            <AttendanceEditor
              siswaId={user.role === 'siswa' ? user.id : selectedSiswa}
              onSaved={() => setRefresh(r => r + 1)}
              editing={editing}
              setEditing={setEditing}
              withinTime={withinTime}
              isSiswa={user.role === 'siswa'}
            />
          ) : (
            <FormEditor type={type} siswaId={user.role === 'siswa' ? user.id : selectedSiswa} onSaved={() => setRefresh(r => r + 1)} editing={editing} setEditing={setEditing} />
          )}

          <div className="bg-white rounded-xl shadow p-5 border border-slate-200">
            <h3 className="font-semibold text-slate-800 mb-4">📋 Data Tersimpan ({entries.length})</h3>
            {entries.length === 0 ? (
              <div className="text-center py-10 text-slate-400 text-sm">Belum ada data. Silakan isi di atas.</div>
            ) : type === 'attendance' ? (
              <AttendanceTable entries={entries} onEdit={(id) => setEditing(id)} onRemove={remove} />
            ) : type === 'journal' ? (
              <JournalTable entries={entries as JournalEntry[]} onEdit={(id) => setEditing(id)} onRemove={remove} />
            ) : type === 'observation' ? (
              <ObservationTable entries={entries as ObservationEntry[]} onEdit={(id) => setEditing(id)} onRemove={remove} onSign={(id) => setSigningId(id)} canSign={user.role !== 'siswa'} />
            ) : (
              <ActivityTable entries={entries as ActivityEntry[]} onEdit={(id) => setEditing(id)} onRemove={remove} />
            )}
          </div>

          {/* Signature Modal for observation paraf DUDI */}
          {type === 'observation' && signingId && (
            <ObservationSignatureModal
              entryId={signingId}
              onClose={() => setSigningId(null)}
              onSaved={() => { setRefresh(r => r + 1); setSigningId(null); }}
            />
          )}

          {entries.length > 0 && activeSiswa && (
            <div ref={sheetRef} className="bg-white rounded-xl shadow p-8 border border-slate-200" style={{ minHeight: '297mm' }}>
              <SheetHeader title={(() => { const t = textCustomStore.get(); return (t as any)[cfg.sheetTitleKey] || cfg.sheetTitleFallback; })()} siswa={activeSiswa} />
              {type === 'attendance' && <AttendancePrint entries={entries as AttendanceEntry[]} siswa={activeSiswa} />}
              {type === 'journal' && <JournalPrint entries={entries as JournalEntry[]} />}
              {type === 'observation' && <ObservationPrint entries={entries as ObservationEntry[]} />}
              {type === 'activity' && <ActivityPrint entries={entries as ActivityEntry[]} />}
              <SignaturesFooter siswa={activeSiswa} />
            </div>
          )}
        </>
      )}
    </div>
  );
}

/* ============== ATTENDANCE EDITOR (with location & time lock) ============== */

function AttendanceEditor({ siswaId, onSaved, editing, setEditing, withinTime, isSiswa }: { siswaId: string; onSaved: () => void; editing: string | null; setEditing: (id: string | null) => void; withinTime: boolean; isSiswa: boolean; }) {
  const editItem = editing ? attendanceStore.all().find((x: any) => x.id === editing) : null;
  const settings = settingsStore.get();

  const emptyForm = {
    tanggal: new Date().toISOString().slice(0, 10),
    statusKehadiran: 'Hadir',
    keteranganPenjelas: '',
    tempat: '',
    datangPukul: new Date().toTimeString().slice(0, 5),
    pulangPukul: '',
    lokasiLink: '',
    lokasiLat: '',
    lokasiLng: '',
    waktuIsi: new Date().toISOString(),
    terlambat: false,
  };

  const [form, setForm] = useState<any>(editItem || emptyForm);

  useEffect(() => {
    if (editItem) setForm(editItem);
    else setForm({ ...emptyForm, tanggal: new Date().toISOString().slice(0, 10), datangPukul: new Date().toTimeString().slice(0, 5) });
  }, [editing, siswaId]);

  function submit(e: React.FormEvent) {
    e.preventDefault();
    const status = form.statusKehadiran || 'Hadir';
    if (!form.tanggal || !status || !form.keteranganPenjelas?.trim()) {
      alert('⚠️ Kolom Tanggal, Status Kehadiran, dan Keterangan Penjelas wajib diisi.');
      return;
    }
    if (status === 'Hadir' && (!form.tempat?.trim() || !form.datangPukul || !form.pulangPukul)) {
      alert('⚠️ Untuk status Hadir, semua kolom wajib diisi:\n• Tempat PKL\n• Datang Pukul\n• Pulang Pukul\n• Keterangan Penjelas');
      return;
    }
    // Check tolerance
    let terlambat = false;
    if (form.datangPukul && settings.toleranceMinutes) {
      const [sh, sm] = settings.startHour.split(':').map(Number);
      const [dh, dm] = String(form.datangPukul).split(':').map(Number);
      const startMin = sh * 60 + sm;
      const datangMin = dh * 60 + dm;
      if (datangMin > startMin + settings.toleranceMinutes) terlambat = true;
    }
    const data = { ...form, statusKehadiran: status, terlambat, waktuIsi: form.waktuIsi || new Date().toISOString() };
    if (editing) {
      attendanceStore.update({ ...data, id: editing, siswaId });
      setEditing(null);
    } else {
      attendanceStore.add({ ...data, id: uid(), siswaId });
    }
    onSaved();
    setForm({ ...emptyForm, tanggal: new Date().toISOString().slice(0, 10), datangPukul: new Date().toTimeString().slice(0, 5) });
  }

  const locked = isSiswa && !withinTime && !editing;

  return (
    <form onSubmit={submit} className={`bg-white rounded-xl shadow p-4 border border-slate-200 ${locked ? 'opacity-70' : ''}`}>
      <div className="flex items-center justify-between mb-4 flex-wrap gap-2">
        <h3 className="font-semibold text-slate-800">{editing ? '✏️ Edit Presensi' : '📍 Tambah Presensi PKL'}</h3>
        {editing && <button type="button" onClick={() => setEditing(null)} className="text-xs text-slate-500 hover:underline">Batal</button>}
      </div>

      {locked && <div className="mb-4 p-3 bg-rose-50 border border-rose-200 rounded-lg text-sm text-rose-700">🔒 Presensi hanya bisa diisi pada jam {settings.startHour} - {settings.endHour} WIB.</div>}

      {/* Kolom ditampilkan BARIS SATU PER SATU KE BAWAH (vertikal) */}
      <div className="space-y-3">
        <div>
          <label className="block text-sm font-medium text-slate-700 mb-1">Tanggal <span className="text-rose-600">*</span></label>
          <input type="date" value={form.tanggal} onChange={e => setForm({ ...form, tanggal: e.target.value })} className="w-full px-3 py-2 border border-slate-300 rounded-lg" required disabled={locked} />
        </div>
        <div>
          <label className="block text-sm font-medium text-slate-700 mb-1">Status Kehadiran <span className="text-rose-600">*</span></label>
          <select value={form.statusKehadiran || 'Hadir'} onChange={e => setForm({ ...form, statusKehadiran: e.target.value })} className="w-full px-3 py-2 border border-slate-300 rounded-lg" required disabled={locked}>
            <option value="Hadir">Hadir</option>
            <option value="Sakit">Sakit</option>
            <option value="Ijin">Ijin</option>
          </select>
          <p className="text-xs text-slate-500 mt-1">Jika memilih Sakit/Ijin, isi kolom keterangan penjelas dengan alasan.</p>
        </div>
        <div>
          <label className="block text-sm font-medium text-slate-700 mb-1">Tempat PKL {(form.statusKehadiran || 'Hadir') === 'Hadir' && <span className="text-rose-600">*</span>}</label>
          <input value={form.tempat} onChange={e => setForm({ ...form, tempat: e.target.value })} className="w-full px-3 py-2 border border-slate-300 rounded-lg" placeholder="Nama tempat / perusahaan PKL" disabled={locked || (form.statusKehadiran || 'Hadir') !== 'Hadir'} required={(form.statusKehadiran || 'Hadir') === 'Hadir'} />
        </div>
        <div className="grid grid-cols-2 gap-3">
          <div>
            <label className="block text-sm font-medium text-slate-700 mb-1">Datang Pukul {(form.statusKehadiran || 'Hadir') === 'Hadir' && <span className="text-rose-600">*</span>}</label>
            <input type="time" value={form.datangPukul} onChange={e => setForm({ ...form, datangPukul: e.target.value })} className="w-full px-3 py-2 border border-slate-300 rounded-lg" disabled={locked || (form.statusKehadiran || 'Hadir') !== 'Hadir'} required={(form.statusKehadiran || 'Hadir') === 'Hadir'} />
          </div>
          <div>
            <label className="block text-sm font-medium text-slate-700 mb-1">Pulang Pukul {(form.statusKehadiran || 'Hadir') === 'Hadir' && <span className="text-rose-600">*</span>}</label>
            <input type="time" value={form.pulangPukul} onChange={e => setForm({ ...form, pulangPukul: e.target.value })} className="w-full px-3 py-2 border border-slate-300 rounded-lg" disabled={locked || (form.statusKehadiran || 'Hadir') !== 'Hadir'} required={(form.statusKehadiran || 'Hadir') === 'Hadir'} />
          </div>
        </div>
        <div>
          <label className="block text-sm font-medium text-slate-700 mb-1">Keterangan Penjelas <span className="text-rose-600">*</span></label>
          <textarea rows={3} value={form.keteranganPenjelas || ''} onChange={e => setForm({ ...form, keteranganPenjelas: e.target.value })} className="w-full px-3 py-2 border border-slate-300 rounded-lg" placeholder={(form.statusKehadiran || 'Hadir') === 'Hadir' ? 'Contoh: Hadir mengikuti PKL sesuai jadwal.' : 'Tuliskan alasan sakit/ijin secara jelas.'} required disabled={locked} />
        </div>
      </div>

      <div className="mt-5">
        <button type="submit" disabled={locked} className="px-5 py-2 bg-emerald-700 hover:bg-emerald-800 disabled:bg-slate-300 text-white rounded-lg font-medium">{editing ? '💾 Simpan Perubahan' : '💾 Simpan Presensi'}</button>
      </div>
    </form>
  );
}

/* ============== GENERIC FORM EDITOR ============== */

function FormEditor({ type, siswaId, onSaved, editing, setEditing }: { type: FormType; siswaId: string; onSaved: () => void; editing: string | null; setEditing: (id: string | null) => void; }) {
  const store = type === 'journal' ? journalStore : type === 'observation' ? observationStore : activityStore;
  const editItem = editing ? store.all().find((x: any) => x.id === editing) : null;

  const emptyForm = {
    tanggal: new Date().toISOString().slice(0, 10),
    unitKerja: '', catatan: '',
    kompetensi: '', indikator: '', paraf: '',
    namaPekerjaan: '', perencanaan: '', pelaksanaan: '', catatanInstruktur: '',
  };

  const [form, setForm] = useState<any>(editItem || emptyForm);

  useEffect(() => {
    if (editItem) setForm(editItem);
    else setForm({ ...emptyForm, tanggal: new Date().toISOString().slice(0, 10) });
  }, [editing, siswaId]);

  function submit(e: React.FormEvent) {
    e.preventDefault();
    // Validasi semua kolom wajib diisi
    if (type === 'journal') {
      if (!form.tanggal || !form.unitKerja?.trim() || !form.catatan?.trim()) {
        alert('⚠️ Semua kolom wajib diisi:\n• Tanggal\n• Unit Kerja / Pekerjaan\n• Catatan');
        return;
      }
    } else if (type === 'observation') {
      if (!form.tanggal || !form.kompetensi?.trim() || !form.indikator?.trim() || !form.catatan?.trim()) {
        alert('⚠️ Semua kolom wajib diisi:\n• Tanggal\n• Kompetensi\n• Indikator Keberhasilan\n• Catatan');
        return;
      }
    } else if (type === 'activity') {
      if (!form.tanggal || !form.namaPekerjaan?.trim() || !form.perencanaan?.trim() || !form.pelaksanaan?.trim() || !form.catatanInstruktur?.trim()) {
        alert('⚠️ Semua kolom wajib diisi:\n• Tanggal\n• A. Nama Pekerjaan\n• B. Perencanaan Kegiatan\n• C. Pelaksanaan Kegiatan / Hasil\n• D. Catatan Instruktur');
        return;
      }
    }
    if (editing) { store.update({ ...form, id: editing, siswaId }); setEditing(null); }
    else store.add({ ...form, id: uid(), siswaId });
    onSaved();
    setForm({ ...emptyForm, tanggal: new Date().toISOString().slice(0, 10) });
  }

  // Kolom ditampilkan BARIS SATU PER SATU KE BAWAH (vertikal)
  if (type === 'journal') {
    return (
      <form onSubmit={submit} className="bg-white rounded-xl shadow p-5 border border-slate-200">
        <div className="flex items-center justify-between mb-4 flex-wrap gap-2">
          <h3 className="font-semibold text-slate-800">{editing ? '✏️ Edit Jurnal' : '📓 Tambah Jurnal Kegiatan'}</h3>
          {editing && <button type="button" onClick={() => setEditing(null)} className="text-xs text-slate-500 hover:underline">Batal</button>}
        </div>
        <div className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-slate-700 mb-1">Tanggal <span className="text-rose-600">*</span></label>
            <input type="date" value={form.tanggal} onChange={e => setForm({ ...form, tanggal: e.target.value })} className="w-full px-3 py-2 border border-slate-300 rounded-lg" required />
          </div>
          <div>
            <label className="block text-sm font-medium text-slate-700 mb-1">Unit Kerja / Pekerjaan <span className="text-rose-600">*</span></label>
            <input value={form.unitKerja} onChange={e => setForm({ ...form, unitKerja: e.target.value })} className="w-full px-3 py-2 border border-slate-300 rounded-lg" required />
          </div>
          <div>
            <label className="block text-sm font-medium text-slate-700 mb-1">Catatan <span className="text-rose-600">*</span></label>
            <textarea rows={3} value={form.catatan} onChange={e => setForm({ ...form, catatan: e.target.value })} className="w-full px-3 py-2 border border-slate-300 rounded-lg" required />
          </div>
        </div>
        <div className="mt-5">
          <button type="submit" className="px-5 py-2 bg-emerald-700 hover:bg-emerald-800 text-white rounded-lg font-medium">{editing ? '💾 Simpan Perubahan' : '💾 Simpan'}</button>
        </div>
      </form>
    );
  }

  if (type === 'observation') {
    return (
      <form onSubmit={submit} className="bg-white rounded-xl shadow p-5 border border-slate-200">
        <div className="flex items-center justify-between mb-4 flex-wrap gap-2">
          <h3 className="font-semibold text-slate-800">{editing ? '✏️ Edit Observasi' : '🔍 Tambah Laporan Observasi'}</h3>
          {editing && <button type="button" onClick={() => setEditing(null)} className="text-xs text-slate-500 hover:underline">Batal</button>}
        </div>
        <div className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-slate-700 mb-1">Tanggal <span className="text-rose-600">*</span></label>
            <input type="date" value={form.tanggal} onChange={e => setForm({ ...form, tanggal: e.target.value })} className="w-full px-3 py-2 border border-slate-300 rounded-lg" required />
          </div>
          <div>
            <label className="block text-sm font-medium text-slate-700 mb-1">Kompetensi <span className="text-rose-600">*</span></label>
            <input value={form.kompetensi} onChange={e => setForm({ ...form, kompetensi: e.target.value })} className="w-full px-3 py-2 border border-slate-300 rounded-lg" required />
          </div>
          <div>
            <label className="block text-sm font-medium text-slate-700 mb-1">Indikator Keberhasilan <span className="text-rose-600">*</span></label>
            <input value={form.indikator} onChange={e => setForm({ ...form, indikator: e.target.value })} className="w-full px-3 py-2 border border-slate-300 rounded-lg" required />
          </div>
          <div>
            <label className="block text-sm font-medium text-slate-700 mb-1">Catatan <span className="text-rose-600">*</span></label>
            <textarea rows={3} value={form.catatan} onChange={e => setForm({ ...form, catatan: e.target.value })} className="w-full px-3 py-2 border border-slate-300 rounded-lg" required />
          </div>
        </div>
        <div className="mt-4 bg-emerald-50 border border-emerald-200 rounded-lg p-3 text-sm text-emerald-800">
          💡 Tanda tangan Guru Pembimbing dan Instruktur DUDI akan diisi oleh Admin/Guru secara terpisah.
        </div>
        <div className="mt-5">
          <button type="submit" className="px-5 py-2 bg-emerald-700 hover:bg-emerald-800 text-white rounded-lg font-medium">{editing ? '💾 Simpan Perubahan' : '💾 Simpan'}</button>
        </div>
      </form>
    );
  }

  // Activity form tetap menggunakan textarea karena isinya panjang
  return (
    <form onSubmit={submit} className="bg-white rounded-xl shadow p-4 border border-slate-200">
      <div className="flex items-center justify-between mb-3 flex-wrap gap-2">
        <h3 className="font-semibold text-slate-800 text-sm">{editing ? '✏️ Edit Catatan' : '📑 Tambah Catatan Kegiatan'}</h3>
        {editing && <button type="button" onClick={() => setEditing(null)} className="text-xs text-slate-500 hover:underline">Batal</button>}
      </div>
      <div className="space-y-3">
        <div>
          <label className="block text-xs font-medium text-slate-700 mb-1">Tanggal <span className="text-rose-600">*</span></label>
          <input type="date" value={form.tanggal} onChange={e => setForm({ ...form, tanggal: e.target.value })} className="w-full px-2 py-1.5 border border-slate-300 rounded-lg text-sm max-w-xs" required />
        </div>
        <div>
          <label className="block text-xs font-medium text-slate-700 mb-1">A. Nama Pekerjaan <span className="text-rose-600">*</span></label>
          <input value={form.namaPekerjaan} onChange={e => setForm({ ...form, namaPekerjaan: e.target.value })} className="w-full px-2 py-1.5 border border-slate-300 rounded-lg text-sm" required />
        </div>
        <div>
          <label className="block text-xs font-medium text-slate-700 mb-1">B. Perencanaan Kegiatan <span className="text-rose-600">*</span></label>
          <textarea rows={2} value={form.perencanaan} onChange={e => setForm({ ...form, perencanaan: e.target.value })} className="w-full px-2 py-1.5 border border-slate-300 rounded-lg text-sm" required />
        </div>
        <div>
          <label className="block text-xs font-medium text-slate-700 mb-1">C. Pelaksanaan / Hasil <span className="text-rose-600">*</span></label>
          <textarea rows={3} value={form.pelaksanaan} onChange={e => setForm({ ...form, pelaksanaan: e.target.value })} className="w-full px-2 py-1.5 border border-slate-300 rounded-lg text-sm" required />
        </div>
        <div>
          <label className="block text-xs font-medium text-slate-700 mb-1">D. Catatan Instruktur <span className="text-rose-600">*</span></label>
          <textarea rows={2} value={form.catatanInstruktur} onChange={e => setForm({ ...form, catatanInstruktur: e.target.value })} className="w-full px-2 py-1.5 border border-slate-300 rounded-lg text-sm" required />
        </div>
      </div>
      <div className="mt-3">
        <button type="submit" className="px-4 py-1.5 bg-emerald-700 hover:bg-emerald-800 text-white rounded-lg text-sm font-medium">💾 Simpan</button>
      </div>
    </form>
  );
}

/* ============== TABLES ============== */

function AttendanceTable({ entries, onEdit, onRemove }: { entries: AttendanceEntry[]; onEdit: (id: string) => void; onRemove: (id: string) => void; }) {
  return (
    <div className="overflow-x-auto">
      <table className="w-full text-sm">
        <thead><tr className="bg-slate-100">
          <th className="border border-slate-300 px-3 py-2 w-12">No.</th>
          <th className="border border-slate-300 px-3 py-2 w-40">Hari, Tanggal</th>
          <th className="border border-slate-300 px-3 py-2 w-28">Keterangan</th>
          <th className="border border-slate-300 px-3 py-2">Tempat</th>
          <th className="border border-slate-300 px-3 py-2 w-24">Datang</th>
          <th className="border border-slate-300 px-3 py-2 w-24">Pulang</th>
          <th className="border border-slate-300 px-3 py-2 w-44">Waktu Isi</th>
          <th className="border border-slate-300 px-3 py-2 w-28">Keterlambatan</th>
          <th className="border border-slate-300 px-3 py-2">Penjelasan</th>
          <th className="border border-slate-300 px-3 py-2 w-28">Aksi</th>
        </tr></thead>
        <tbody>
          {entries.map((e, i) => (
            <tr key={e.id} className={e.terlambat ? 'bg-amber-50' : ''}>
              <td className="border border-slate-300 px-3 py-2 text-center">{i + 1}</td>
              <td className="border border-slate-300 px-3 py-2">{new Date(e.tanggal).toLocaleDateString('id-ID', { weekday: 'long', day: '2-digit', month: 'long', year: 'numeric' })}</td>
              <td className="border border-slate-300 px-3 py-2 text-center">
                <span className={`text-xs px-2 py-0.5 rounded-full font-semibold ${(e.statusKehadiran || 'Hadir') === 'Hadir' ? 'bg-emerald-100 text-emerald-700' : (e.statusKehadiran || 'Hadir') === 'Sakit' ? 'bg-amber-100 text-amber-700' : 'bg-blue-100 text-blue-700'}`}>{e.statusKehadiran || 'Hadir'}</span>
              </td>
              <td className="border border-slate-300 px-3 py-2">{(e.statusKehadiran || 'Hadir') === 'Hadir' ? e.tempat : '-'}</td>
              <td className="border border-slate-300 px-3 py-2 text-center">{(e.statusKehadiran || 'Hadir') === 'Hadir' ? e.datangPukul : '-'}</td>
              <td className="border border-slate-300 px-3 py-2 text-center">{(e.statusKehadiran || 'Hadir') === 'Hadir' ? (e.pulangPukul || '-') : '-'}</td>
              <td className="border border-slate-300 px-3 py-2 text-xs text-slate-600">{e.waktuIsi ? new Date(e.waktuIsi).toLocaleString('id-ID') : '-'}</td>
              <td className="border border-slate-300 px-3 py-2 text-center">
                {(e.statusKehadiran || 'Hadir') !== 'Hadir' ? <span className="text-xs text-slate-400">-</span> : e.terlambat ? <span className="text-xs bg-amber-200 text-amber-900 px-2 py-0.5 rounded-full font-semibold">TERLAMBAT</span> : <span className="text-xs bg-emerald-100 text-emerald-700 px-2 py-0.5 rounded-full">✓ Tepat</span>}
              </td>
              <td className="border border-slate-300 px-3 py-2 text-sm">{e.keteranganPenjelas || '-'}</td>
              <td className="border border-slate-300 px-3 py-2 text-center space-x-2 whitespace-nowrap">
                <button onClick={() => onEdit(e.id)} className="text-blue-600 text-xs hover:underline">Edit</button>
                <button onClick={() => onRemove(e.id)} className="text-rose-600 text-xs hover:underline">Hapus</button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

function JournalTable({ entries, onEdit, onRemove }: { entries: JournalEntry[]; onEdit: (id: string) => void; onRemove: (id: string) => void; }) {
  return (
    <table className="w-full text-sm">
      <thead><tr className="bg-slate-100">
        <th className="border border-slate-300 px-3 py-2 w-12">No.</th>
        <th className="border border-slate-300 px-3 py-2 w-40">Hari/Tanggal</th>
        <th className="border border-slate-300 px-3 py-2">Unit Kerja/Pekerjaan</th>
        <th className="border border-slate-300 px-3 py-2">Catatan*</th>
        <th className="border border-slate-300 px-3 py-2 w-28">Aksi</th>
      </tr></thead>
      <tbody>
        {entries.map((e, i) => (
          <tr key={e.id}>
            <td className="border border-slate-300 px-3 py-2 text-center">{i + 1}</td>
            <td className="border border-slate-300 px-3 py-2">{new Date(e.tanggal).toLocaleDateString('id-ID')}</td>
            <td className="border border-slate-300 px-3 py-2">{e.unitKerja}</td>
            <td className="border border-slate-300 px-3 py-2">{e.catatan}</td>
            <td className="border border-slate-300 px-3 py-2 text-center space-x-2 whitespace-nowrap">
              <button onClick={() => onEdit(e.id)} className="text-blue-600 text-xs hover:underline">Edit</button>
              <button onClick={() => onRemove(e.id)} className="text-rose-600 text-xs hover:underline">Hapus</button>
            </td>
          </tr>
        ))}
      </tbody>
    </table>
  );
}

function ObservationTable({ entries, onEdit, onRemove, onSign, canSign }: { entries: ObservationEntry[]; onEdit: (id: string) => void; onRemove: (id: string) => void; onSign: (id: string) => void; canSign: boolean; }) {
  return (
    <div className="overflow-x-auto">
      <table className="w-full text-sm">
        <thead><tr className="bg-slate-100">
          <th className="border border-slate-300 px-3 py-2 w-28">Tanggal</th>
          <th className="border border-slate-300 px-3 py-2">Kompetensi</th>
          <th className="border border-slate-300 px-3 py-2">Indikator</th>
          <th className="border border-slate-300 px-3 py-2">Catatan</th>
          <th className="border border-slate-300 px-3 py-2 w-40">Tanda Tangan DUDI</th>
          <th className="border border-slate-300 px-3 py-2 w-40">Aksi</th>
        </tr></thead>
        <tbody>
          {entries.map((e) => (
            <tr key={e.id}>
              <td className="border border-slate-300 px-3 py-2">{new Date(e.tanggal).toLocaleDateString('id-ID')}</td>
              <td className="border border-slate-300 px-3 py-2">{e.kompetensi}</td>
              <td className="border border-slate-300 px-3 py-2">{e.indikator}</td>
              <td className="border border-slate-300 px-3 py-2">{e.catatan}</td>
              <td className="border border-slate-300 px-3 py-2 text-center">
                {e.parafSignature ? (
                  <div>
                    <img src={e.parafSignature} alt="ttd" className="h-12 mx-auto object-contain" />
                    {e.parafNama && <div className="text-xs text-slate-600 mt-1">{e.parafNama}</div>}
                  </div>
                ) : e.paraf ? (
                  <div className="text-xs text-slate-600">{e.paraf}</div>
                ) : (
                  <span className="text-xs text-slate-400">Belum ditandatangani</span>
                )}
              </td>
              <td className="border border-slate-300 px-3 py-2 text-center space-x-1 whitespace-nowrap">
                <button onClick={() => onEdit(e.id)} className="text-blue-600 text-xs hover:underline">Edit</button>
                {canSign && <button onClick={() => onSign(e.id)} className="text-emerald-700 text-xs hover:underline">{e.parafSignature ? 'Ubah TTD' : '✍️ TTD DUDI'}</button>}
                <button onClick={() => onRemove(e.id)} className="text-rose-600 text-xs hover:underline">Hapus</button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

function ActivityTable({ entries, onEdit, onRemove }: { entries: ActivityEntry[]; onEdit: (id: string) => void; onRemove: (id: string) => void; }) {
  return (
    <div className="space-y-4">
      {entries.map((e, i) => (
        <div key={e.id} className="border border-slate-300 rounded-lg p-4">
          <div className="flex items-start justify-between mb-3">
            <div className="text-sm font-semibold text-slate-800">#{i + 1} — {new Date(e.tanggal).toLocaleDateString('id-ID', { weekday: 'long', day: '2-digit', month: 'long', year: 'numeric' })}</div>
            <div className="space-x-2">
              <button onClick={() => onEdit(e.id)} className="text-blue-600 text-xs hover:underline">Edit</button>
              <button onClick={() => onRemove(e.id)} className="text-rose-600 text-xs hover:underline">Hapus</button>
            </div>
          </div>
          <div className="space-y-3 text-sm">
            <div><div className="font-semibold text-slate-700">A. Nama Pekerjaan</div><div className="border border-slate-300 rounded p-2 min-h-8">{e.namaPekerjaan || '-'}</div></div>
            <div><div className="font-semibold text-slate-700">B. Perencanaan Kegiatan</div><div className="border border-slate-300 rounded p-2 min-h-12 whitespace-pre-wrap">{e.perencanaan || '-'}</div></div>
            <div><div className="font-semibold text-slate-700">C. Pelaksanaan / Hasil</div><div className="border border-slate-300 rounded p-2 min-h-16 whitespace-pre-wrap">{e.pelaksanaan || '-'}</div></div>
            <div><div className="font-semibold text-slate-700">D. Catatan Instruktur</div><div className="border border-slate-300 rounded p-2 min-h-12 whitespace-pre-wrap">{e.catatanInstruktur || '-'}</div></div>
          </div>
        </div>
      ))}
    </div>
  );
}

/* ============== PRINTS ============== */

function AttendancePrint({ entries, siswa }: { entries: AttendanceEntry[]; siswa: User; }) {
  return (
    <table className="w-full text-sm border-collapse">
      <thead><tr className="bg-slate-100">
        <th className="border border-slate-800 px-3 py-2 w-12">No.</th>
        <th className="border border-slate-800 px-3 py-2 w-44">Hari, Tanggal</th>
        <th className="border border-slate-800 px-3 py-2 w-24">Keterangan</th>
        <th className="border border-slate-800 px-3 py-2">Tempat</th>
        <th className="border border-slate-800 px-3 py-2 w-24">Datang</th>
        <th className="border border-slate-800 px-3 py-2 w-24">Pulang</th>
        <th className="border border-slate-800 px-3 py-2 w-40">Waktu Isi</th>
        <th className="border border-slate-800 px-3 py-2">Penjelasan</th>
      </tr></thead>
      <tbody>
        {entries.map((e, i) => (
          <tr key={e.id} style={{ height: 40 }}>
            <td className="border border-slate-800 px-3 py-2 text-center align-top">{i + 1}</td>
            <td className="border border-slate-800 px-3 py-2 align-top">{new Date(e.tanggal).toLocaleDateString('id-ID', { weekday: 'long', day: '2-digit', month: 'long', year: 'numeric' })}</td>
            <td className="border border-slate-800 px-3 py-2 text-center align-top">{e.statusKehadiran || 'Hadir'}</td>
            <td className="border border-slate-800 px-3 py-2 align-top">{(e.statusKehadiran || 'Hadir') === 'Hadir' ? (e.tempat || siswa.tempatPkl || '') : '-'}</td>
            <td className="border border-slate-800 px-3 py-2 text-center align-top">{(e.statusKehadiran || 'Hadir') === 'Hadir' ? e.datangPukul : '-'}</td>
            <td className="border border-slate-800 px-3 py-2 text-center align-top">{(e.statusKehadiran || 'Hadir') === 'Hadir' ? (e.pulangPukul || '-') : '-'}</td>
            <td className="border border-slate-800 px-3 py-2 align-top text-xs">{e.waktuIsi ? new Date(e.waktuIsi).toLocaleString('id-ID') : '-'}</td>
            <td className="border border-slate-800 px-3 py-2 align-top text-xs">{e.keteranganPenjelas || '-'}</td>
          </tr>
        ))}
        {Array.from({ length: Math.max(0, 8 - entries.length) }).map((_, i) => (
          <tr key={'e-' + i} style={{ height: 40 }}>
            <td className="border border-slate-800 px-3 py-2"></td>
            <td className="border border-slate-800 px-3 py-2"></td>
            <td className="border border-slate-800 px-3 py-2"></td>
            <td className="border border-slate-800 px-3 py-2"></td>
            <td className="border border-slate-800 px-3 py-2"></td>
            <td className="border border-slate-800 px-3 py-2"></td>
            <td className="border border-slate-800 px-3 py-2"></td>
            <td className="border border-slate-800 px-3 py-2"></td>
          </tr>
        ))}
      </tbody>
    </table>
  );
}

function JournalPrint({ entries }: { entries: JournalEntry[]; }) {
  return (
    <table className="w-full text-sm border-collapse">
      <thead><tr className="bg-slate-100">
        <th className="border border-slate-800 px-3 py-2 w-12">No.</th>
        <th className="border border-slate-800 px-3 py-2 w-40">Hari/Tanggal</th>
        <th className="border border-slate-800 px-3 py-2">Unit Kerja/Pekerjaan</th>
        <th className="border border-slate-800 px-3 py-2">Catatan*</th>
      </tr></thead>
      <tbody>
        {entries.map((e, i) => (
          <tr key={e.id} style={{ height: 60 }}>
            <td className="border border-slate-800 px-3 py-2 text-center align-top">{i + 1}</td>
            <td className="border border-slate-800 px-3 py-2 align-top">{new Date(e.tanggal).toLocaleDateString('id-ID', { weekday: 'long', day: '2-digit', month: 'long', year: 'numeric' })}</td>
            <td className="border border-slate-800 px-3 py-2 align-top">{e.unitKerja}</td>
            <td className="border border-slate-800 px-3 py-2 align-top">{e.catatan}</td>
          </tr>
        ))}
        {Array.from({ length: Math.max(0, 6 - entries.length) }).map((_, i) => (
          <tr key={'e-' + i} style={{ height: 60 }}>
            <td className="border border-slate-800 px-3 py-2"></td>
            <td className="border border-slate-800 px-3 py-2"></td>
            <td className="border border-slate-800 px-3 py-2"></td>
            <td className="border border-slate-800 px-3 py-2"></td>
          </tr>
        ))}
      </tbody>
    </table>
  );
}

function ObservationPrint({ entries }: { entries: ObservationEntry[]; }) {
  return (
    <table className="w-full text-sm border-collapse">
      <thead><tr className="bg-slate-100">
        <th className="border border-slate-800 px-3 py-2 w-32">Tanggal</th>
        <th className="border border-slate-800 px-3 py-2">Kompetensi</th>
        <th className="border border-slate-800 px-3 py-2">Indikator Keberhasilan</th>
        <th className="border border-slate-800 px-3 py-2">Catatan</th>
        <th className="border border-slate-800 px-3 py-2 w-40">Paraf / Tanda Tangan DUDI</th>
      </tr></thead>
      <tbody>
        {entries.map((e) => (
          <tr key={e.id} style={{ height: 70 }}>
            <td className="border border-slate-800 px-3 py-2 align-top">{new Date(e.tanggal).toLocaleDateString('id-ID')}</td>
            <td className="border border-slate-800 px-3 py-2 align-top">{e.kompetensi}</td>
            <td className="border border-slate-800 px-3 py-2 align-top">{e.indikator}</td>
            <td className="border border-slate-800 px-3 py-2 align-top">{e.catatan}</td>
            <td className="border border-slate-800 px-3 py-2 align-top text-center">
              {e.parafSignature ? (
                <div>
                  <img src={e.parafSignature} alt="ttd" className="h-12 mx-auto object-contain" />
                  {e.parafNama && <div className="text-xs mt-1">{e.parafNama}</div>}
                </div>
              ) : e.paraf ? (
                <div className="text-xs">{e.paraf}</div>
              ) : null}
            </td>
          </tr>
        ))}
        {Array.from({ length: Math.max(0, 6 - entries.length) }).map((_, i) => (
          <tr key={'e-' + i} style={{ height: 70 }}>
            <td className="border border-slate-800 px-3 py-2"></td>
            <td className="border border-slate-800 px-3 py-2"></td>
            <td className="border border-slate-800 px-3 py-2"></td>
            <td className="border border-slate-800 px-3 py-2"></td>
            <td className="border border-slate-800 px-3 py-2"></td>
          </tr>
        ))}
      </tbody>
    </table>
  );
}

/* ============== SIGNATURE FOOTER (for print sheets) ============== */

function SignaturesFooter({ siswa }: { siswa?: User }) {
  // Ambil tanda tangan guru pembimbing (berdasarkan siswa.pembimbingId atau yang pertama)
  const allSigs = signaturesStore.all();
  const guruSigs = allSigs.filter(s => s.type === 'guru');
  const dudiSigs = allSigs.filter(s => s.type === 'dudi');

  // Pilih tanda tangan guru: jika ada ownerUserId == pembimbingId siswa, pilih itu; else pilih pertama
  let guru = guruSigs.find(s => siswa?.pembimbingId && s.ownerUserId === siswa.pembimbingId);
  if (!guru && guruSigs.length > 0) guru = guruSigs[0];

  const dudi = dudiSigs[0]; // ambil satu DUDI (bisa dikembangkan: pilih berdasarkan tempat PKL)

  if (!guru && !dudi) return null;

  return (
    <div className="mt-10 pt-6 border-t border-slate-300">
      <div className="grid grid-cols-2 gap-8">
        {/* Guru Pembimbing */}
        <div className="text-center text-sm">
          <div className="font-semibold text-slate-800">Mengetahui,</div>
          <div className="font-semibold text-slate-800">{guru?.jabatan || 'Guru Pembimbing PKL'}</div>
          <div className="text-slate-600 text-xs mt-1">SMK Muhammadiyah 2 Playen</div>
          <div className="h-24 flex items-center justify-center my-2">
            {guru?.signature ? <img src={guru.signature} alt="ttd" className="h-20 object-contain" /> : <div className="text-xs text-slate-400 italic">(tanda tangan)</div>}
          </div>
          {guru && (
            <>
              <div className="border-t border-slate-400 w-48 mx-auto"></div>
              <div className="font-semibold text-slate-800 mt-1">{guru.namaLengkap}</div>
              {guru.showNbm !== false && <div className="text-xs text-slate-600">NBM. {guru.nbm || '-'}</div>}
            </>
          )}
        </div>

        {/* Instruktur DUDI */}
        <div className="text-center text-sm">
          <div className="font-semibold text-slate-800">Menyetujui,</div>
          <div className="font-semibold text-slate-800">{dudi?.jabatan || 'Instruktur / Pembimbing DUDI'}</div>
          <div className="text-slate-600 text-xs mt-1">{dudi?.tempatPkl || (siswa?.tempatPkl ? siswa.tempatPkl : 'Tempat PKL')}</div>
          <div className="h-24 flex items-center justify-center my-2">
            {dudi?.signature ? <img src={dudi.signature} alt="ttd" className="h-20 object-contain" /> : <div className="text-xs text-slate-400 italic">(tanda tangan)</div>}
          </div>
          {dudi && (
            <>
              <div className="border-t border-slate-400 w-48 mx-auto"></div>
              <div className="font-semibold text-slate-800 mt-1">{dudi.namaLengkap}</div>
              {dudi.showNbm !== false && <div className="text-xs text-slate-600">NBM. {dudi.nbm || '-'}</div>}
            </>
          )}
        </div>
      </div>

    </div>
  );
}

/* ============== SIGNATURE MODAL for Observation Paraf DUDI ============== */

function ObservationSignatureModal({ entryId, onClose, onSaved }: { entryId: string; onClose: () => void; onSaved: () => void; }) {
  const entry = observationStore.all().find((x: any) => x.id === entryId);
  const [sig, setSig] = useState(entry?.parafSignature || '');
  const [nama, setNama] = useState(entry?.parafNama || '');
  const [uploadMode, setUploadMode] = useState(false);
  const fileRef = useRef<HTMLInputElement>(null);

  if (!entry) return null;

  function onFile(e: React.ChangeEvent<HTMLInputElement>) {
    const f = e.target.files?.[0];
    if (!f) return;
    const reader = new FileReader();
    reader.onload = () => setSig(reader.result as string);
    reader.readAsDataURL(f);
  }

  function save() {
    observationStore.update({ ...(entry as any), parafSignature: sig, parafNama: nama });
    onSaved();
  }

  return (
    <div className="fixed inset-0 bg-black/60 flex items-center justify-center p-4 z-50">
      <div className="bg-white rounded-2xl shadow-2xl w-full max-w-2xl max-h-[92vh] overflow-y-auto">
        <div className="p-5 border-b border-slate-200 flex items-center justify-between sticky top-0 bg-white">
          <div>
            <h3 className="text-lg font-bold text-slate-800">✍️ Tanda Tangan DUDI / Instruktur</h3>
            <p className="text-xs text-slate-500">Laporan Observasi tgl {new Date(entry.tanggal).toLocaleDateString('id-ID')} — {entry.kompetensi}</p>
          </div>
          <button onClick={onClose} className="text-slate-400 hover:text-slate-600 text-2xl leading-none">&times;</button>
        </div>

        <div className="p-5 space-y-4">
          <div>
            <label className="block text-sm font-medium text-slate-700 mb-1">Nama Instruktur/DUDI</label>
            <input value={nama} onChange={e => setNama(e.target.value)} className="w-full px-3 py-2 border border-slate-300 rounded-lg" placeholder="Nama lengkap penandatangan dari DUDI" />
          </div>

          <div className="flex gap-2">
            <button onClick={() => setUploadMode(false)} className={`px-3 py-1.5 text-sm rounded-lg ${!uploadMode ? 'bg-emerald-700 text-white' : 'bg-slate-100 text-slate-700'}`}>✍️ Tulis Tanda Tangan</button>
            <button onClick={() => setUploadMode(true)} className={`px-3 py-1.5 text-sm rounded-lg ${uploadMode ? 'bg-emerald-700 text-white' : 'bg-slate-100 text-slate-700'}`}>📷 Upload Foto TTD</button>
          </div>

          {!uploadMode ? (
            <SignaturePad value={sig} onChange={setSig} />
          ) : (
            <div className="space-y-2">
              <input ref={fileRef} type="file" accept="image/*" onChange={onFile} className="block w-full text-sm file:mr-4 file:py-2 file:px-4 file:rounded-lg file:border-0 file:bg-emerald-700 file:text-white" />
              {sig && <div className="border-2 border-dashed border-slate-300 rounded-lg p-4 bg-white text-center"><img src={sig} alt="ttd" className="h-32 mx-auto object-contain" /></div>}
            </div>
          )}

          <div className="flex justify-end gap-2 pt-2 border-t border-slate-200">
            <button onClick={onClose} className="px-4 py-2 bg-slate-100 hover:bg-slate-200 rounded-lg text-slate-700">Batal</button>
            <button onClick={save} className="px-5 py-2 bg-emerald-700 hover:bg-emerald-800 text-white rounded-lg font-medium">💾 Simpan Tanda Tangan</button>
          </div>
        </div>
      </div>
    </div>
  );
}

function ActivityPrint({ entries }: { entries: ActivityEntry[]; }) {
  return (
    <div className="space-y-6">
      {entries.map((e, i) => (
        <div key={e.id} className="border-2 border-slate-800 p-4 rounded">
          <div className="font-bold mb-3">Kegiatan #{i + 1} — {new Date(e.tanggal).toLocaleDateString('id-ID', { weekday: 'long', day: '2-digit', month: 'long', year: 'numeric' })}</div>
          <div className="space-y-3 text-sm">
            <div><div className="font-semibold mb-1">A. Nama Pekerjaan</div><div className="border border-slate-800 p-3 min-h-10">{e.namaPekerjaan}</div></div>
            <div><div className="font-semibold mb-1">B. Perencanaan Kegiatan</div><div className="border border-slate-800 p-3 min-h-16 whitespace-pre-wrap">{e.perencanaan}</div></div>
            <div><div className="font-semibold mb-1">C. Pelaksanaan / Hasil</div><div className="border border-slate-800 p-3 min-h-24 whitespace-pre-wrap">{e.pelaksanaan}</div></div>
            <div><div className="font-semibold mb-1">D. Catatan Instruktur</div><div className="border border-slate-800 p-3 min-h-16 whitespace-pre-wrap">{e.catatanInstruktur}</div></div>
          </div>
        </div>
      ))}
    </div>
  );
}

import { useState } from 'react';
import { settingsStore, AttendanceSettings } from '../store';

export default function SettingsPage() {
  const [settings, setSettings] = useState<AttendanceSettings>(settingsStore.get());
  const [saved, setSaved] = useState(false);

  function save() {
    settingsStore.save(settings);
    setSaved(true);
    setTimeout(() => setSaved(false), 2500);
  }

  return (
    <div className="space-y-6 max-w-3xl">
      <div>
        <h2 className="text-2xl font-bold text-slate-800">⚙️ Pengaturan Sistem</h2>
        <p className="text-sm text-slate-500">Konfigurasi waktu presensi & pengaturan umum</p>
      </div>

      <div className="bg-white rounded-xl shadow p-6 border border-slate-200">
        <h3 className="font-semibold text-slate-800 mb-4">⏰ Jam Kerja Presensi PKL</h3>
        <p className="text-xs text-slate-500 mb-4">Siswa hanya bisa mengisi daftar hadir PKL pada rentang jam dibawah ini. Di luar jam tersebut, tombol presensi akan terkunci.</p>

        <div className="grid md:grid-cols-3 gap-4">
          <div>
            <label className="block text-sm font-medium text-slate-700 mb-1">Jam Mulai Presensi</label>
            <input type="time" value={settings.startHour} onChange={e => setSettings({ ...settings, startHour: e.target.value })} className="w-full px-3 py-2 border border-slate-300 rounded-lg" />
            <p className="text-xs text-slate-400 mt-1">Sebelum jam ini = presensi ditutup</p>
          </div>
          <div>
            <label className="block text-sm font-medium text-slate-700 mb-1">Jam Tutup Presensi</label>
            <input type="time" value={settings.endHour} onChange={e => setSettings({ ...settings, endHour: e.target.value })} className="w-full px-3 py-2 border border-slate-300 rounded-lg" />
            <p className="text-xs text-slate-400 mt-1">Sesudah jam ini = presensi ditutup</p>
          </div>
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-1">Toleransi Keterlambatan (menit)</label>
              <input type="number" min={0} value={settings.toleranceMinutes} onChange={e => setSettings({ ...settings, toleranceMinutes: Number(e.target.value) })} className="w-full px-3 py-2 border border-slate-300 rounded-lg" />
              <p className="text-xs text-slate-400 mt-1">Melebihi toleransi = ditandai terlambat</p>
            </div>
            <div className="md:col-span-3 rounded-xl border border-emerald-200 bg-emerald-50 p-4">
              <label className="block text-sm font-bold text-emerald-900 mb-1">Jurusan Aktif yang Ditampilkan di Sistem</label>
              <input value={settings.jurusanAktif} onChange={e => setSettings({ ...settings, jurusanAktif: e.target.value })} className="w-full px-3 py-2 border border-slate-300 rounded-lg" placeholder="Contoh: Teknik Komputer dan Jaringan" />
              <p className="text-xs text-emerald-700 mt-2">Nama jurusan ini akan terlihat di halaman login, dashboard, dan header sistem untuk semua pengguna.</p>
            </div>
          </div>

          <div className="mt-6 flex items-center gap-3">
            <button onClick={save} className="px-5 py-2 bg-emerald-700 hover:bg-emerald-800 text-white rounded-lg font-medium">💾 Simpan Pengaturan</button>
            {saved && <span className="text-sm text-emerald-600">✓ Pengaturan berhasil disimpan</span>}
          </div>

        <div className="mt-6 bg-slate-50 border border-slate-200 rounded-lg p-4 text-sm text-slate-600">
          <b>Status saat ini:</b> Presensi dibuka pada <b>{settings.startHour}</b> - <b>{settings.endHour}</b> WIB dengan toleransi <b>{settings.toleranceMinutes} menit</b>.<br/>
          <b>Jurusan Aktif:</b> {settings.jurusanAktif}
        </div>
      </div>

      <div className="bg-amber-50 border border-amber-200 rounded-xl p-4 text-sm text-amber-800">
        💡 <b>Catatan:</b> Pengaturan ini berlaku untuk seluruh siswa. Waktu dihitung berdasarkan waktu perangkat masing-masing siswa.
      </div>
    </div>
  );
}

import { useEffect, useState } from 'react';
import { User } from './types';
import { initStore, usersStore } from './store';
import LoginPage from './pages/LoginPage';
import DashboardPage from './pages/DashboardPage';
import MonitoringPage from './pages/MonitoringPage';
import StudentFormsPage from './pages/StudentFormsPage';
import UsersPage from './pages/UsersPage';
import SignatureManagePage from './pages/SignatureManagePage';
import StudentsWorkPage from './pages/StudentsWorkPage';
import SettingsPage from './pages/SettingsPage';
import TextCustomPage from './pages/TextCustomPage';
import Layout from './components/Layout';
import { ThemeProvider } from './components/ThemeProvider';

export default function App() {
  const [user, setUser] = useState<User | null>(null);
  const [page, setPage] = useState('dashboard');

  useEffect(() => {
    initStore();
    const s = usersStore.session();
    if (s) setUser(s);
  }, []);

  if (!user) return <ThemeProvider><LoginPage onLogin={setUser} /></ThemeProvider>;

  function navigate(p: string) {
    setPage(p);
    window.scrollTo(0, 0);
  }

  const renderPage = () => {
    // Admin access: everything
    // Guru: dashboard, monitoring, students-work, signature
    // Siswa: dashboard, attendance, journal, observation, activity
    if (page === 'dashboard') return <DashboardPage user={user} onNavigate={navigate} />;
    if (page === 'users' && user.role === 'admin') return <UsersPage />;
    if (page === 'settings' && user.role === 'admin') return <SettingsPage />;
    if (page === 'textcustom' && user.role === 'admin') return <TextCustomPage />;
    if (page === 'monitoring' && user.role !== 'siswa') return <MonitoringPage user={user} />;
    if (page === 'students-work' && user.role !== 'siswa') return <StudentsWorkPage user={user} />;
    if (page === 'signature' && user.role !== 'siswa') return <SignatureManagePage user={user} />;
    if (page === 'signature' && user.role === 'siswa') return <DashboardPage user={user} onNavigate={navigate} />;
    if (page === 'attendance') return <StudentFormsPage user={user} type="attendance" />;
    if (page === 'journal') return <StudentFormsPage user={user} type="journal" />;
    if (page === 'observation') return <StudentFormsPage user={user} type="observation" />;
    if (page === 'activity') return <StudentFormsPage user={user} type="activity" />;
    return <DashboardPage user={user} onNavigate={navigate} />;
  };

  return (
    <ThemeProvider>
      <Layout user={user} active={page} onNavigate={navigate}>
        {renderPage()}
      </Layout>
    </ThemeProvider>
  );
}

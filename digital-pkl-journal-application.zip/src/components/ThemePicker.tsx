import { useState } from 'react';
import { themes } from '../store';
import { useTheme } from './ThemeProvider';

export default function ThemePicker() {
  const { theme, setThemeId } = useTheme();
  const [open, setOpen] = useState(false);

  return (
    <div className="relative">
      <button
        onClick={() => setOpen(!open)}
        className="flex items-center gap-2 px-3 py-1.5 bg-white hover:bg-slate-50 border border-slate-200 rounded-lg text-sm text-slate-700 shadow-sm"
        title="Ubah Tema"
      >
        <span className="w-4 h-4 rounded-full border border-slate-300" style={{ background: theme.swatch }} />
        <span className="hidden sm:inline">🎨 Tema</span>
      </button>
      {open && (
        <>
          <div className="fixed inset-0 z-40" onClick={() => setOpen(false)} />
          <div className="absolute right-0 mt-2 w-72 bg-white rounded-xl shadow-2xl border border-slate-200 p-4 z-50">
            <div className="font-bold text-slate-800 mb-3 text-sm">🎨 Pilih Tema Warna</div>
            <div className="grid grid-cols-2 gap-2">
              {themes.map(t => (
                <button
                  key={t.id}
                  onClick={() => { setThemeId(t.id); setOpen(false); }}
                  className={`flex items-center gap-2 p-2 rounded-lg border-2 text-left text-xs transition ${theme.id === t.id ? 'border-slate-800 bg-slate-50' : 'border-slate-200 hover:border-slate-400'}`}
                >
                  <span className="w-5 h-5 rounded-full shrink-0 border border-slate-300" style={{ background: t.swatch }} />
                  <span className="truncate text-slate-700">{t.name}</span>
                  {theme.id === t.id && <span className="ml-auto text-emerald-600">✓</span>}
                </button>
              ))}
            </div>
            <div className="mt-3 pt-3 border-t border-slate-200 text-xs text-slate-500 text-center">
              10 pilihan tema • Tersimpan otomatis
            </div>
          </div>
        </>
      )}
    </div>
  );
}

interface Props {
  targetRef: React.RefObject<HTMLElement>;
  label?: string;
  className?: string;
  title?: string;
}

export default function PrintButton({ targetRef, label = '🖨️ Cetak', className, title = 'Laporan PKL' }: Props) {
  function doPrint() {
    const el = targetRef.current;
    if (!el) return;

    // Create print window
    const printWindow = window.open('', '_blank', 'width=1200,height=800');
    if (!printWindow) {
      alert('Browser memblokir jendela cetak. Silakan izinkan pop-up untuk situs ini.');
      return;
    }

    // Clone element to strip interactive content
    const clone = el.cloneNode(true) as HTMLElement;
    // Hide all buttons/actions in cloned content
    clone.querySelectorAll('button, input, textarea, select, .no-print').forEach(n => (n as HTMLElement).style.display = 'none');

    const html = `
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8" />
  <title>${title}</title>
  <style>
    @page { size: A4 portrait; margin: 15mm; }
    body { font-family: 'Times New Roman', serif; color: #111; margin: 0; padding: 0; }
    table { width: 100%; border-collapse: collapse; margin: 8px 0; }
    th, td { border: 1px solid #000 !important; padding: 6px 8px; font-size: 11pt; vertical-align: top; }
    th { background: #eee; font-weight: bold; }
    h1, h2, h3 { text-align: center; font-family: 'Times New Roman', serif; }
    img { max-width: 100%; }
    .border-slate-800, .border-slate-300, [class*="border-"] { border: 1px solid #000 !important; }
    .bg-yellow-200, .bg-slate-100, [class*="bg-"] { background: transparent; }
    .text-slate-900, .text-slate-800, .text-slate-700, [class*="text-"] { color: #000; }
    .rounded, .rounded-lg, .rounded-xl { border-radius: 0; }
    .shadow, .shadow-sm, [class*="shadow"] { box-shadow: none; }
    .p-1, .p-2, .p-3, .p-4, .p-5, .p-6, .p-8 { padding: 4px; }
    .space-y-6 > * + * { margin-top: 12pt; }
    .space-y-4 > * + * { margin-top: 8pt; }
    .space-y-3 > * + * { margin-top: 6pt; }
    .grid { display: block; }
    .grid-cols-2 > * { display: block; margin: 8pt 0; }
    .flex { display: block; }
    .border-b-4 { border-bottom: 3px double #000 !important; padding-bottom: 6pt; margin-bottom: 12pt; }
    .border-t { border-top: 1px solid #000; }
    .text-center { text-align: center; }
    .text-right { text-align: right; }
    .font-bold, .font-semibold { font-weight: bold; }
    .text-xs { font-size: 9pt; }
    .text-sm { font-size: 10pt; }
    .text-lg { font-size: 13pt; }
    .text-xl { font-size: 14pt; }
    .text-2xl { font-size: 18pt; }
    .mt-1, .mt-2, .mt-3, .mt-4, .mt-6, .mt-8, .mt-10 { margin-top: 6pt; }
    .mb-1, .mb-2, .mb-3, .mb-4 { margin-bottom: 4pt; }
    .pt-1, .pt-2, .pt-3, .pt-4, .pt-6 { padding-top: 4pt; }
    .pb-1, .pb-2, .pb-3, .pb-4 { padding-bottom: 4pt; }
    .px-3, .px-4 { padding-left: 4pt; padding-right: 4pt; }
    .py-1, .py-2 { padding-top: 2pt; padding-bottom: 2pt; }
    .min-h-8, .min-h-10, .min-h-12, .min-h-16, .min-h-24 { min-height: 20pt; }
    .break-words { word-break: break-word; }
    .whitespace-pre-wrap { white-space: pre-wrap; }
    .w-12, .w-24, .w-28, .w-32, .w-40, .w-44, .w-48 { width: auto; }
    .h-10, .h-12, .h-16, .h-20, .h-24 { height: auto; }
    .object-contain { object-fit: contain; }
    .mx-auto { margin-left: auto; margin-right: auto; }
    .border-double { border-style: double; }
    @media print {
      .no-print { display: none !important; }
    }
  </style>
</head>
<body>
  ${clone.outerHTML}
  <script>
    window.onload = function() {
      setTimeout(function() {
        window.focus();
        window.print();
      }, 400);
    };
  </script>
</body>
</html>`;

    printWindow.document.open();
    printWindow.document.write(html);
    printWindow.document.close();
  }

  return (
    <button type="button" onClick={doPrint} className={className ?? 'inline-flex items-center gap-2 px-4 py-2 bg-blue-700 hover:bg-blue-800 text-white text-sm font-medium rounded-lg shadow-sm'}>
      {label}
    </button>
  );
}

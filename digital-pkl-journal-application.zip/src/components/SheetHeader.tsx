import { User } from '../types';
import { textCustomStore } from '../store';

interface Props {
  title: string;
  subtitle?: string;
  user?: User;
  siswa?: User;
  showSignature?: boolean;
  signatureLabel?: string;
  signatureData?: string;
}

export default function SheetHeader({ title, subtitle, user, siswa, showSignature, signatureLabel, signatureData }: Props) {
  const t = textCustomStore.get();
  return (
    <div className="bg-white">
      {/* Kop Surat */}
      <div className="border-b-4 border-double border-slate-800 pb-3 mb-4">
        <div className="flex items-center gap-4">
          <div className="w-16 h-16"></div>
          <div className="flex-1 text-center">
            <div className="text-2xl font-bold text-slate-900">{t.sekolahNama}</div>
            <div className="text-xs text-slate-700 mt-1">{t.sekolahAlamat}</div>
            <div className="text-xs text-slate-700">{t.sekolahKontak}</div>
          </div>
          <div className="w-16 h-16"></div>
        </div>
      </div>

      <div className="text-center mb-4">
        <div className="inline-block bg-yellow-200 px-6 py-1.5 rounded">
          <h2 className="text-xl font-bold text-slate-900 tracking-wide">{title}</h2>
        </div>
        {subtitle && <p className="text-sm text-slate-600 mt-2">{subtitle}</p>}
      </div>

      {(siswa || user) && (
        <div className="grid grid-cols-2 gap-x-8 gap-y-1 text-sm mb-4 px-4">
          {siswa && (
            <>
              <div><span className="inline-block w-28">Nama</span>: <b>{siswa.name}</b></div>
              <div><span className="inline-block w-28">NIS</span>: {siswa.nis || '-'}</div>
              <div><span className="inline-block w-28">Kelas</span>: {siswa.kelas || '-'}</div>
              <div><span className="inline-block w-28">Jurusan</span>: {siswa.jurusan || '-'}</div>
              <div className="col-span-2"><span className="inline-block w-28">Tempat PKL</span>: {siswa.tempatPkl || '-'}</div>
            </>
          )}
          {user && !siswa && (
            <>
              <div><span className="inline-block w-28">Guru Pembimbing</span>: <b>{user.name}</b></div>
              <div><span className="inline-block w-28">NIP</span>: {user.nip || '-'}</div>
            </>
          )}
        </div>
      )}

      {showSignature && signatureData && (
        <div className="flex justify-end mb-3">
          <div className="text-center">
            <div className="text-xs text-slate-600 mb-1">{signatureLabel || 'Tanda Tangan'}</div>
            <img src={signatureData} alt="signature" className="h-16 object-contain mx-auto bg-white" />
            <div className="border-t border-slate-400 w-40 mt-1 text-xs text-slate-500 pt-1">Nama Jelas</div>
          </div>
        </div>
      )}
    </div>
  );
}

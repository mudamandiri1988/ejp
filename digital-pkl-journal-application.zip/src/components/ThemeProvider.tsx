import { createContext, useContext, useEffect, useState, ReactNode } from 'react';
import { themeStore, ThemeDef } from '../store';

interface ThemeContextValue {
  theme: ThemeDef;
  setThemeId: (id: string) => void;
}

const ThemeContext = createContext<ThemeContextValue | null>(null);

export function ThemeProvider({ children }: { children: ReactNode }) {
  const [themeId, setThemeIdState] = useState<string>(themeStore.get());

  useEffect(() => {
    const t = themeStore.current();
    document.documentElement.style.setProperty('--theme-primary', t.swatch);
    document.documentElement.setAttribute('data-theme', t.id);
  }, [themeId]);

  function setThemeId(id: string) {
    themeStore.save(id);
    setThemeIdState(id);
  }

  const theme = themeStore.current();
  // Force re-render by including themeId in key pattern
  return (
    <ThemeContext.Provider value={{ theme, setThemeId }}>
      <div key={themeId}>{children}</div>
    </ThemeContext.Provider>
  );
}

export function useTheme() {
  const ctx = useContext(ThemeContext);
  if (!ctx) return { theme: themeStore.current(), setThemeId: (id: string) => themeStore.save(id) };
  return ctx;
}

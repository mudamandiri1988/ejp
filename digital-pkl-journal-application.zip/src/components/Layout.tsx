import { ReactNode, useState } from 'react';
import { User } from '../types';
import { settingsStore, usersStore } from '../store';
import { useTheme } from './ThemeProvider';
import ThemePicker from './ThemePicker';

interface Props {
  user: User;
  active: string;
  onNavigate: (page: string) => void;
  children: ReactNode;
}

const menus: Record<string, { label: string; icon: string; page: string }[]> = {
  admin: [
    { label: 'Dashboard', icon: '🏠', page: 'dashboard' },
    { label: 'Kelola Pengguna', icon: '👥', page: 'users' },
    { label: 'Pengaturan', icon: '⚙️', page: 'settings' },
    { label: 'Kustom Teks', icon: '✏️', page: 'textcustom' },
    { label: 'Monitoring', icon: '📋', page: 'monitoring' },
    { label: 'Daftar Hadir', icon: '📍', page: 'attendance' },
    { label: 'Jurnal', icon: '📓', page: 'journal' },
    { label: 'Observasi', icon: '🔍', page: 'observation' },
    { label: 'Catatan', icon: '📑', page: 'activity' },
    { label: 'Tanda Tangan', icon: '✍️', page: 'signature' },
  ],
  guru: [
    { label: 'Dashboard', icon: '🏠', page: 'dashboard' },
    { label: 'Monitoring', icon: '📋', page: 'monitoring' },
    { label: 'Pekerjaan Siswa', icon: '👀', page: 'students-work' },
    { label: 'Tanda Tangan', icon: '✍️', page: 'signature' },
  ],
  siswa: [
    { label: 'Dashboard', icon: '🏠', page: 'dashboard' },
    { label: 'Daftar Hadir', icon: '📍', page: 'attendance' },
    { label: 'Jurnal', icon: '📓', page: 'journal' },
    { label: 'Observasi', icon: '🔍', page: 'observation' },
    { label: 'Catatan', icon: '📑', page: 'activity' },
  ],
};

export default function Layout({ user, active, onNavigate, children }: Props) {
  const menu = menus[user.role] || [];
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const theme = useTheme().theme;
  const settings = settingsStore.get();

  function go(page: string) { onNavigate(page); setSidebarOpen(false); }

  return (
    <div className="min-h-screen bg-slate-50 flex">
      {/* Mobile overlay */}
      {sidebarOpen && (
        <div className="fixed inset-0 bg-black/50 z-40 lg:hidden" onClick={() => setSidebarOpen(false)} />
      )}

      {/* Sidebar */}
      <aside className={`fixed lg:sticky top-0 h-screen w-72 bg-gradient-to-b ${theme.primary} ${theme.primary2} text-white flex flex-col z-50 transform transition-transform duration-300 lg:translate-x-0 ${sidebarOpen ? 'translate-x-0' : '-translate-x-full'}`}>
        <div className="p-5 border-b border-white/20 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-white/20 flex items-center justify-center text-xl shrink-0">SMK</div>
            <div className="min-w-0">
              <div className="font-bold text-sm leading-tight truncate">SMK MUHAMMADIYAH</div>
              <div className="text-xs text-white/80">2 PLAYEN</div>
            </div>
          </div>
          <button className="lg:hidden text-white/80 hover:text-white text-xl px-2" onClick={() => setSidebarOpen(false)}>&times;</button>
        </div>
        <nav className="flex-1 p-3 space-y-1 overflow-y-auto">
          {menu.map(m => (
            <button
              key={m.page}
              onClick={() => go(m.page)}
              className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm text-left transition ${active === m.page ? 'bg-white text-slate-800 font-semibold shadow' : 'text-white/90 hover:bg-white/15'}`}
            >
              <span className="text-base shrink-0">{m.icon}</span>
              <span className="truncate">{m.label}</span>
            </button>
          ))}
        </nav>
        <div className="p-3 border-t border-white/20 space-y-2">
          <button
            onClick={() => { usersStore.logout(); location.reload(); }}
            className="w-full flex items-center justify-center gap-2 px-3 py-2 rounded-lg bg-white/15 hover:bg-white/25 text-sm font-semibold text-white transition"
          >
            🚪 Logout Akun
          </button>
          <div className="text-xs text-white/70 text-center">© {new Date().getFullYear()} SMK Muhammadiyah 2 Playen</div>
        </div>
      </aside>

      {/* Main */}
      <div className="flex-1 flex flex-col min-w-0">
        <header className={`bg-white border-b border-slate-200 px-4 sm:px-6 py-3 flex items-center gap-2 sm:gap-4 sticky top-0 z-30 shadow-sm`}>
          <button
            className="lg:hidden p-2 rounded-lg hover:bg-slate-100 text-slate-700"
            onClick={() => setSidebarOpen(true)}
            aria-label="Buka menu"
          >
            <svg className="w-6 h-6" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" d="M4 6h16M4 12h16M4 18h16" /></svg>
          </button>
          <div className="min-w-0 flex-1">
            <h1 className="text-base sm:text-lg font-bold text-slate-800 truncate">Sistem Jurnal Laporan PKL</h1>
            <p className="text-xs text-slate-500 hidden sm:block">Pengelolaan Praktek Kerja Lapangan secara digital</p>
            <div className={`mt-1 inline-flex max-w-full items-center gap-1 rounded-full ${theme.badgeBg} ${theme.badgeText} px-2 py-0.5 text-[11px] font-semibold sm:hidden`}>
              <span>Jurusan:</span>
              <span className="truncate">{settings.jurusanAktif || '-'}</span>
            </div>
          </div>
          <div className={`hidden lg:flex max-w-xs items-center gap-2 rounded-full ${theme.badgeBg} ${theme.badgeText} px-3 py-1.5 text-xs font-semibold`} title="Jurusan Aktif">
            <span>Jurusan Aktif:</span>
            <span className="truncate">{settings.jurusanAktif || '-'}</span>
          </div>
          {user.role === 'admin' && <ThemePicker />}
          <div className="hidden md:flex items-center gap-3">
            <div className="text-right">
              <div className="text-sm font-semibold text-slate-800 truncate max-w-[160px]">{user.name}</div>
              <div className="text-xs text-slate-500 capitalize">{user.role === 'admin' ? 'Administrator' : user.role === 'guru' ? 'Guru Pembimbing' : 'Siswa'}</div>
            </div>
            <div className={`w-10 h-10 rounded-full ${theme.accentBg} ${theme.primaryText} flex items-center justify-center font-bold shrink-0`}>{user.name.charAt(0)}</div>
            <button onClick={() => { usersStore.logout(); location.reload(); }} className="px-3 py-1.5 text-sm bg-slate-100 hover:bg-slate-200 rounded-md text-slate-700 hidden lg:block">Logout Akun</button>
          </div>
          <div className="md:hidden flex items-center gap-2">
            <div className={`w-9 h-9 rounded-full ${theme.accentBg} ${theme.primaryText} flex items-center justify-center font-bold text-sm shrink-0`}>{user.name.charAt(0)}</div>
            <button onClick={() => { usersStore.logout(); location.reload(); }} className="px-2 py-1.5 text-xs bg-slate-100 hover:bg-slate-200 rounded-md text-slate-700" title="Logout Akun">🚪</button>
          </div>
        </header>
        <main className="flex-1 p-3 sm:p-6 overflow-y-auto">{children}</main>
      </div>
    </div>
  );
}

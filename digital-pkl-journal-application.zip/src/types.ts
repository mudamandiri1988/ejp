export type Role = 'admin' | 'guru' | 'siswa';

export interface User {
  id: string;
  username: string;
  password: string;
  role: Role;
  name: string;
  nip?: string;
  nis?: string;
  kelas?: string;
  jurusan?: string;
  tempatPkl?: string;
  pembimbingId?: string;
  signature?: string; // base64 image
}

export interface MonitoringEntry {
  id: string;
  guruId: string;
  siswaId: string;
  tanggal: string;
  catatan: string;
}

export interface AttendanceEntry {
  id: string;
  siswaId: string;
  tanggal: string;
  statusKehadiran?: 'Hadir' | 'Sakit' | 'Ijin';
  keteranganPenjelas?: string;
  tempat: string;
  datangPukul: string;
  pulangPukul: string;
  // Old: parafPetugas (nama/paraf). New: share lokasi (Google Maps link) + koordinat + waktu submit
  lokasiLink?: string;
  lokasiLat?: string;
  lokasiLng?: string;
  waktuIsi: string; // ISO timestamp saat presensi diisi
  terlambat?: boolean;
  parafPetugas?: string; // kept for backward
}

export interface JournalEntry {
  id: string;
  siswaId: string;
  tanggal: string;
  unitKerja: string;
  catatan: string;
}

export interface ObservationEntry {
  id: string;
  siswaId: string;
  tanggal: string;
  kompetensi: string;
  indikator: string;
  catatan: string;
  // Old: paraf (text). New: parafSignature (base64 image) — tanda tangan DUDI
  paraf?: string;
  parafSignature?: string; // base64 image tanda tangan digital DUDI
  parafNama?: string; // nama penandatangan (DUDI / instruktur)
}

export interface ActivityEntry {
  id: string;
  siswaId: string;
  tanggal: string;
  namaPekerjaan: string;
  perencanaan: string;
  pelaksanaan: string;
  catatanInstruktur: string;
}
